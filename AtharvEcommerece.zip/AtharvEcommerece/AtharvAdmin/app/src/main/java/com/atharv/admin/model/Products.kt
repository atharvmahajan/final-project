package com.atharv.admin.model

import com.google.firebase.firestore.ServerTimestamp
import java.io.Serializable
import java.util.*


data class Products(
    val category: String? = "",
    val description: String? = "",
    val images: List<String>? = null,
    val price: String? = "",
    val status: String? = "",
    val title: String? = "",
    @ServerTimestamp
    val time: Date? = null,
    val productId: String? = "",
    val views: Int? = 0,
): Serializable
