package com.shoplinks.shoplinkuser.home

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.shoplinks.shoplinkuser.R
import com.shoplinks.shoplinkuser.adapters.ProductRecyclerAdapter
import com.shoplinks.shoplinkuser.databinding.FragmentBottomSheetBinding
import com.shoplinks.shoplinkuser.databinding.FragmentHomeBinding
import com.shoplinks.shoplinkuser.model.Products
import com.shoplinks.shoplinkuser.utils.Constants
import com.shoplinks.shoplinkuser.utils.DbConstants

class BottomSheetFragment : BottomSheetDialogFragment(), ProductRecyclerAdapter.OnItemClickListener {

    companion object {

        const val TAG = "HomeFragment"
    }

    private var _binding: FragmentBottomSheetBinding? = null
    private val binding get() = _binding!!
    private val productsList = mutableListOf<Products>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?): View? {
        _binding = FragmentBottomSheetBinding.inflate(inflater, container, false)
        val view = binding.root

//        hideProgressBar()
        fetchProducts()
        return view
    }

    private fun fetchProducts() {

//        launch {
        productsList.clear()
//        showProgressBar()
        val db = Firebase.firestore
        val docRef = db.collection(DbConstants.PRODUCTS)

        docRef
            .whereEqualTo(Constants.STATUS_KEY, Constants.APPROVED)
            .get()
            .addOnSuccessListener { result ->
                if (!result.isEmpty) {
                    for (document in result) {
                        Log.d(HomeFragment.TAG, "${document.id} => ${document.data}")
                        val products = document.toObject(Products::class.java)
                        productsList.add(products)
                    }

                    initRecyclerView()

                    Toast.makeText(
                        context,
                        "Products fetched.",
                        Toast.LENGTH_SHORT,
                    ).show()
                } else {
                    Toast.makeText(
                        context,
                        "Failed to fetch products",
                        Toast.LENGTH_SHORT,
                    ).show()

                }
//                hideProgressBar()
            }
            .addOnFailureListener { exception ->
                Log.d(HomeFragment.TAG, "Error getting documents: ", exception)
                Toast.makeText(
                    context,
                    exception.message.toString(),
                    Toast.LENGTH_SHORT,
                ).show()

//                hideProgressBar()
            }

//        }

    }

    private fun initRecyclerView() {

        if (productsList.isNotEmpty()) {
//            binding.recyclerView.man
            binding.let {
                it.recyclerView.adapter =
                    ProductRecyclerAdapter(productsList, this, requireContext())
            }

        }
    }

    override fun onItemClick(item: Products) {


    }

    override fun onCartClick(item: Products) {
    }

    override fun onSellerLocationClick(item: Products) {
    }

}