package com.atharv.seller

import android.content.Intent
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.bold
import androidx.core.text.color
import androidx.core.view.isVisible
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.atharv.seller.adapters.ImageSlideAdapter
import com.atharv.seller.databinding.ActivityProductDetailBinding
import com.atharv.seller.databinding.EditProductPriceDialogDesingBinding
import com.atharv.seller.model.Products
import com.atharv.seller.utils.DbConstants
import com.atharv.seller.utils.showToast
import java.text.SimpleDateFormat
import java.util.Locale

class ProductDetailActivity : AppCompatActivity() {
    companion object {
        const val TAG = "ProductDetailActivity"
    }

    enum class DeleteMenuState{
        HIDE_MENU, SHOW_MENU
    }

    private lateinit var binding: ActivityProductDetailBinding
    private lateinit var product: Products
    private lateinit var viewPagerAdapter: ImageSlideAdapter
    private val db = Firebase.firestore
    private var menuState =  DeleteMenuState.SHOW_MENU
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProductDetailBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Detail"
        product = intent.getSerializableExtra("product") as Products
        Log.d(TAG, "onCreate: $product")
        hideProgressBar()
        showProduct()
        setViewListeners()

    }

    private fun setViewListeners() {

        binding.apply {
            priceEditIcon.setOnClickListener {

                showEditPriceDialog()
            }

            soldOutButton.setOnClickListener {
                showSoldOutConfirmation()
            }
        }
    }

    private fun showSoldOutConfirmation() {
        val materialAlertDialogBuilder =
            MaterialAlertDialogBuilder(this@ProductDetailActivity)


        // Building the Alert dialog using materialAlertDialogBuilder instance
        materialAlertDialogBuilder
            .setTitle("Confirmation!")
            .setMessage("Are you sure you want to change the status of product to \"SOLD OUT\"?")
            .setPositiveButton(android.R.string.ok) { dialog, _ ->

                binding.soldOutButton.isEnabled = false
                showProgressBar()

                db.collection(DbConstants.PRODUCTS)
                    .document(product.productId!!)
                    .update("soldOut", true)
                    .addOnCompleteListener {

                        if (it.isSuccessful) {
                            binding.soldOutButton.isVisible = false
                        }else {
                            showToast(this@ProductDetailActivity, it.exception?.message)

                            binding.soldOutButton.isEnabled = true
                        }


                        hideProgressBar()

                    }.addOnFailureListener {
                        showToast(this@ProductDetailActivity, it.message)
                        hideProgressBar()
                        binding.soldOutButton.isEnabled = true

                    }
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
                hideProgressBar()
            }
            .show()

    }

    private fun showEditPriceDialog() {
        val materialAlertDialogBuilder =
            MaterialAlertDialogBuilder(this@ProductDetailActivity)
        val customAlertDialogView =
            EditProductPriceDialogDesingBinding.inflate(layoutInflater)


        // Building the Alert dialog using materialAlertDialogBuilder instance
        materialAlertDialogBuilder.setView(customAlertDialogView.root)
            .setTitle("Change Price")
            .setPositiveButton(R.string.save, null)
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
                hideProgressBar()
            }
            .create()

        val alertDialog = materialAlertDialogBuilder.show()


        alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val newPrice = customAlertDialogView.newPriceEt.text.toString().trim()

            if (newPrice.isNotEmpty()) {

                showProgressBar()
                db.collection(DbConstants.PRODUCTS)
                    .document(product.productId!!)
                    .update("price", newPrice)
                    .addOnCompleteListener {

                        if (it.isSuccessful) {
                            val priceString = SpannableStringBuilder()
                                .append(resources.getString(R.string.currency_symbol))
                                .bold { append(newPrice) }
                            binding.priceTv.text = priceString
                            product.price = newPrice
                        }


                        hideProgressBar()

                    }.addOnFailureListener {
                        showToast(this@ProductDetailActivity, it.message)
                        hideProgressBar()
                    }

                alertDialog.dismiss()
            } else {
                customAlertDialogView.newPriceTextInputLayout.error = "Price can not be blank"
                customAlertDialogView.newPriceTextInputLayout.requestFocus()
                return@setOnClickListener
            }
        }


        product.let {
            customAlertDialogView.oldPriceEt.setText(it.price)

        }
    }

    private fun showProduct() {

        product.let {
            binding.apply {


                viewPagerAdapter = ImageSlideAdapter(this@ProductDetailActivity, it.images)
                viewpager.adapter = viewPagerAdapter

//                Glide.with(this@ProductDetailActivity).load(it.images?.get(0)).into(binding.productIv)

                titleTv.text = it.title
                val priceString = SpannableStringBuilder()
                    .append(resources.getString(R.string.currency_symbol))
                    .bold { append("${it.price}") }
                priceTv.text = priceString
                statusTv.text = it.status
                if (it.status == "Pending") {
                    statusTv.setTextColor(resources.getColor(R.color.red))
                    priceEditIcon.isVisible = false
                    soldOutButton.isVisible = false
                }
                else {
                    statusTv.setTextColor(resources.getColor(R.color.green))
                }
                descriptionTv.text = it.description

                val dateFormatted = it.time?.let {
                    SimpleDateFormat(
                        "dd/MM/yyyy hh:mm a",
                        Locale.getDefault()
                    ).format(it)
                }

                dateTv.text = dateFormatted
                val myCustomizedString = SpannableStringBuilder()
                    .color(resources.getColor(R.color.black)) { bold { append("${it.views}") } }
                    .append(" Views")
                viewsTv.text = myCustomizedString
            }
        }

    }

//    override fun onOptionsItemSelected(item: MenuItem): Boolean {
//        when (item.itemId) {
//            android.R.id.home -> {
//                finish()
//                return true
//            }
//        }
//        return super.onOptionsItemSelected(item)
//    }

    private fun hideProgressBar() {
        binding.apply {
            progressBar.root.isVisible = false
//            signUpBtn.isVisible = true
        }
    }

    private fun showProgressBar() {
        binding.apply {
            progressBar.root.isVisible = true
//            signUpBtn.isVisible = false
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.delete_menu, menu)
        val menuItem = menu?.findItem(R.id.action_delete)

        menuItem?.isVisible = menuState != DeleteMenuState.HIDE_MENU
        return super.onCreateOptionsMenu(menu)
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            R.id.action_delete -> {
                showDeleteProductConfirmation()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showDeleteProductConfirmation() {

        val materialAlertDialogBuilder =
            MaterialAlertDialogBuilder(this@ProductDetailActivity)


        // Building the Alert dialog using materialAlertDialogBuilder instance
        materialAlertDialogBuilder
            .setTitle("Confirmation!")
            .setMessage("Are you sure you want to \"DELETE\" this product?")
            .setPositiveButton(android.R.string.ok) { dialog, _ ->

               deleteProduct()
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
                hideProgressBar()
            }
            .show()
    }

    private fun deleteProduct() {

        menuState = DeleteMenuState.HIDE_MENU
        invalidateOptionsMenu()
        showProgressBar()

//        product.images?.forEach { _ ->
//
//        }

        db.collection(DbConstants.PRODUCTS)
            .document(product.productId!!)
            .delete()
            .addOnCompleteListener {

                if (it.isSuccessful) {
//                    menuState = DeleteMenuState.SHOW_MENU
//                    invalidateOptionsMenu()
                    startActivity(Intent(this@ProductDetailActivity, HomeActivity::class.java))
                    finish()
                }else {
                    showToast(this@ProductDetailActivity, it.exception?.message)

                    menuState = DeleteMenuState.SHOW_MENU
                    invalidateOptionsMenu()
                }


                hideProgressBar()

            }.addOnFailureListener {
                showToast(this@ProductDetailActivity, it.message)
                hideProgressBar()
                menuState = DeleteMenuState.SHOW_MENU
                invalidateOptionsMenu()

            }
    }

}