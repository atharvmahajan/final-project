package com.shoplinks.shoplinkuser.model

import android.icu.text.CaseMap.Title

class HeaderItem(
    val title: String?
): ListItem() {

    override fun getType(): Int {
        return Companion.TYPE_HEADER;
    }
}