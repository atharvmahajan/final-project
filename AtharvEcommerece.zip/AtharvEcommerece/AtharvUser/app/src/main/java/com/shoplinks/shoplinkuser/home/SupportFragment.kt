package com.shoplinks.shoplinkuser.home

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.shoplinks.shoplinkuser.adapters.CategoriesRecAdapter
import com.shoplinks.shoplinkuser.databinding.CategoryBottomSheetLayoutBinding
import com.shoplinks.shoplinkuser.databinding.FragmentSupportBinding
import com.shoplinks.shoplinkuser.model.Categories
import com.shoplinks.shoplinkuser.model.CategoryItem
import com.shoplinks.shoplinkuser.model.HeaderItem
import com.shoplinks.shoplinkuser.model.ListItem
import com.shoplinks.shoplinkuser.utils.DbConstants
import com.shoplinks.shoplinkuser.utils.sendTopicNotification
import com.shoplinks.shoplinkuser.utils.toast


class SupportFragment : Fragment() {

    companion object {
        const val TAG = "SupportFragment"
    }

    private var _binding: FragmentSupportBinding? = null
    private val binding get() = _binding!!
    private lateinit var db: FirebaseFirestore
    private lateinit var docRef: CollectionReference
    private val categoriesList = mutableListOf<Categories>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentSupportBinding.inflate(inflater, container, false)

        db = Firebase.firestore
        docRef = db.collection(DbConstants.CATEGORIES)
        getCategories()

        binding.apply {

//            phoneEt.
            categorySelectionTv.setOnClickListener {
                categorySelectionTv.error = null
                if (categoriesList.isNotEmpty())
                    showCategoryBottomSheet()
            }

            sendNotification.setOnClickListener {
                if (phoneEt.text.toString().isEmpty()) {
                    phoneTextInputLayout.error = "Phone number can not be blank"
                    phoneTextInputLayout.requestFocus()
                    return@setOnClickListener
                }

                val categoryStr = "Category"
                if (categorySelectionTv.text == categoryStr) {
                    categorySelectionTv.error = "Category can not be blank"
                    return@setOnClickListener
                }

                sendTopicNotification(
                    categorySelectionTv.text.toString(),
                    "Item Request",
                    "A customer wants ${categorySelectionTv.text}",
                    phoneEt.text.toString(),
                    requireContext().applicationContext
                )
                phoneEt.setText("")
                phoneTextInputLayout.isErrorEnabled = false
                categorySelectionTv.text = categoryStr
            }
        }

        return binding.root
    }

    private fun getCategories() {
        docRef.orderBy("time", Query.Direction.DESCENDING).addSnapshotListener { value, error ->
            if (error != null) {
                requireContext().toast(error.message.toString())
                Log.e(TAG, "getCategories: ${error.message.toString()}")
                return@addSnapshotListener
            }

            categoriesList.clear()
            for (document in value!!) {
                val category = document.toObject(Categories::class.java)
                categoriesList.add(category)
            }

        }

    }


    private fun showCategoryBottomSheet() {

        val groupedHashMap = linkedMapOf(
            "Laptop/Computer" to listOf(
                "Tiny Desktops",
                "Gaming Desktops",
                "Notebook",
                "Ultrabook",
                "Netbook",
                "MacBook",
                "Convertible",
                "MacBook Air"
            ),
            "Shoes" to listOf(
                "Boot",
                "Sneakers",
                "Sandal",
                "Loafer",
                "Oxford shoe",
                "Brogue shoe",
                "Platform shoe",
                "Dress shoe",
                "Ballet flats",
                "Kitten heel"
            ),
            "Cosmetics" to listOf(
                "Hair care",
                "Cosmeceutical",
                "Perfume",
                "Eye shadow",
                "Foundation",
                "Concealer",
                "Mascara",
                "Nail polish",
                "Blush",
                "Lip-stick"
            ),
            "House" to listOf(
                "Apartment",
                "Bungalow",
                "Cottage",
                "Villa",
                "Farmhouse"
            )
        )

        var categories = ArrayList<ListItem>()

        println("before categories: $groupedHashMap")
        for (title in groupedHashMap.keys) {
            val header = HeaderItem(title)
            categories.add(header)
            for (name in groupedHashMap[title]!!) {
                val item = CategoryItem(name)
                categories.add(item)
            }
        }

        println("after categories: $categories")

        // on below line we are creating a new bottom sheet dialog.
        val dialog = BottomSheetDialog(requireContext())

        // on below line we are inflating a layout file which we have created.
//        val view = layoutInflater.inflate(R.layout.category_bottom_sheet_layout, null)
        val view = CategoryBottomSheetLayoutBinding.inflate(LayoutInflater.from(requireContext()))
        dialog.setContentView(view.root)

//        val layoutManager = FlexboxLayoutManager(context)
        view.apply {
//            recyclerView.layoutManager = layoutManager

            recyclerView.adapter = CategoriesRecAdapter(
                categoriesList,
                requireContext(),
                object : CategoriesRecAdapter.OnItemClickListener {
                    override fun onSelectCategory(item: Categories, position: Int) {
                        binding.categorySelectionTv.text = item.name
                        dialog.dismiss()
                    }
                })
        }

        dialog.show()

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}