package com.shoplinks.shoplinkuser.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.shoplinks.shoplinkuser.databinding.SearchListItemBinding


class SearchRecyclerAdapter(
    private val itemList: List<String>,
    private val context: Context,
    private val listener: OnItemClickListener
) :
    RecyclerView.Adapter<SearchRecyclerAdapter.ItemsViewHolder>() {

    interface OnItemClickListener {
        fun selectCategory(name: String?)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): SearchRecyclerAdapter.ItemsViewHolder {
        return ItemsViewHolder(
            SearchListItemBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }


    override fun onBindViewHolder(holder: ItemsViewHolder, position: Int) {


        val categoryItem = itemList[position]
        holder.bind(categoryItem)
    }

    override fun getItemCount() = itemList.size

    inner class ItemsViewHolder(private val binding: SearchListItemBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(categoryItem: String) {
            binding.apply {
                nameTv.text = categoryItem

                root.setOnClickListener {
                    val position = adapterPosition
                    if (position != RecyclerView.NO_POSITION) {
                        listener.selectCategory(categoryItem)
                    }
                }
            }

        }
    }
}