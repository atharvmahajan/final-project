package com.atharv.admin.approveProducts

import android.os.Bundle
import android.text.SpannableStringBuilder
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.text.bold
import androidx.core.text.color
import androidx.core.view.isVisible
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.atharv.admin.R
import com.atharv.admin.adapters.ImageSlideAdapter
import com.atharv.admin.databinding.FragmentProductDetailBinding
import com.atharv.admin.util.DbConstants
import java.text.SimpleDateFormat
import java.util.*

class ProductDetailFragment : Fragment() {
    companion object {
        const val TAG = "ProductDetailFragment"
    }

    private var _binding: FragmentProductDetailBinding? = null
    private val binding get() = _binding!!
    private val productArg: ProductDetailFragmentArgs by navArgs()
    private lateinit var viewPagerAdapter: ImageSlideAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentProductDetailBinding.inflate(inflater, container, false)

        hideProgressBar()
        showProduct()
        setUpClickListeners()
        return binding.root
    }


    private fun setUpClickListeners() {

        binding.apply {

            approvalBtn.setOnClickListener {
                showProgressBar()
                val db = Firebase.firestore
                val docRef =
                    db.collection(DbConstants.PRODUCTS).document(productArg.product.productId!!)

                val updateMap = hashMapOf<String, Any>("status" to "Approved")

                docRef.update(updateMap)
                    .addOnSuccessListener {

                        hideProgressBar()
                        Toast.makeText(
                            context,
                            "Product is Approved.",
                            Toast.LENGTH_SHORT,
                        ).show()
                        findNavController().popBackStack()
                    }.addOnFailureListener {
                        hideProgressBar()
                        Toast.makeText(
                            context,
                            it.message.toString(),
                            Toast.LENGTH_SHORT,
                        ).show()
                    }


            }
        }
    }

    private fun showProduct() {

        productArg.product.let {
            binding.apply {


                viewPagerAdapter = ImageSlideAdapter(requireContext(), it.images!!)
                viewpager.adapter = viewPagerAdapter

                titleTv.text = it.title
                val priceString = SpannableStringBuilder()
                    .append("$")
                    .bold { append("${it.price}") }
                priceTv.text = priceString
                statusTv.text = it.status
                if (it.status == "Pending") {
                    statusTv.setTextColor(resources.getColor(R.color.red))
                    bottomBtnContainer.isVisible = true
                } else {
                    statusTv.setTextColor(resources.getColor(R.color.green))
                    bottomBtnContainer.isVisible = false
                }
                descriptionTv.text = it.description

                val dateFormatted = it.time?.let {
                    SimpleDateFormat(
                        "dd MMM yy. hh:mm a",
                        Locale.getDefault()
                    ).format(it)
                }

                dateTv.text = dateFormatted
                val myCustomizedString = SpannableStringBuilder()
                    .color(resources.getColor(R.color.black)) { bold { append("${it.views}") } }
                    .append(" Views")
                viewsTv.text = myCustomizedString

            }
        }

    }

    private fun hideProgressBar() {
        binding.apply {
            progressBar.root.isVisible = false
            approvalBtn.isVisible = true
        }
    }

    private fun showProgressBar() {
        binding.apply {
            progressBar.root.isVisible = true
            approvalBtn.isVisible = false
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}