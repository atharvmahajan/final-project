package com.shoplinks.shoplinkuser.utils

object DbConstants {

    const val USERS = "users"
    const val PRODUCTS = "products"
    const val NOTIFICATIONS = "notifications"
    const val CATEGORIES = "categories"
    const val BANNERS = "banners"

}