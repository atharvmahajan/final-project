package com.shoplinks.shoplinkuser.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class CartItem(
    @PrimaryKey
    val productId: String,
    val title: String,
    val price: String,
    val quantity: String,
    val image: String,
)
