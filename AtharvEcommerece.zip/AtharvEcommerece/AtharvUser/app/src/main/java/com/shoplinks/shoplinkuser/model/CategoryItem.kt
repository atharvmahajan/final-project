package com.shoplinks.shoplinkuser.model

class CategoryItem(
    val name: String?
    ): ListItem() {
    override fun getType() = TYPE_CATEGORY
}