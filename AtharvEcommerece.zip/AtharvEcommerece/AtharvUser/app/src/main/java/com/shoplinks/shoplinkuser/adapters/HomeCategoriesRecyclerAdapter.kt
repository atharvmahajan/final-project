package com.shoplinks.shoplinkuser.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.shoplinks.shoplinkuser.databinding.CategoriesRecItemDesignBinding
import com.shoplinks.shoplinkuser.databinding.HomeScreeenCategoriesItemDesignBinding
import com.shoplinks.shoplinkuser.model.Categories
import java.text.SimpleDateFormat
import java.util.Locale

class HomeCategoriesRecyclerAdapter(
    private val itemList: List<Categories>,
    private val context: Context,
    private val listener: OnItemClickListener,
) :
    RecyclerView.Adapter<HomeCategoriesRecyclerAdapter.CategoriesViewHolder>() {

    private val listData: MutableList<Categories> = itemList as MutableList<Categories>

    interface OnItemClickListener {
        fun onSelectCategory(item: Categories, position: Int)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoriesViewHolder {
        val binding =
            HomeScreeenCategoriesItemDesignBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        return CategoriesViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CategoriesViewHolder, position: Int) {
        val currentItem = listData[position]
        holder.bind(currentItem)
    }

    override fun getItemCount() = listData.size

    inner class CategoriesViewHolder(private val binding: HomeScreeenCategoriesItemDesignBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: Categories) {
            binding.apply {

//                Picasso.get().load(item.image).into(imageView)
                Glide.with(context).load(item.image).into(categoryIv)
                categoryNameTv.text = item.name
                val dateFormatted = item.time?.let {
                    SimpleDateFormat(
                        "dd MMM yy. hh:mm a",
                        Locale.getDefault()
                    ).format(it)
                }

                root.setOnClickListener {
                    val position = adapterPosition
                    if (position != RecyclerView.NO_POSITION) {
                        val clickedItem = itemList[position]
                        listener.onSelectCategory(item, position)
                    }
                }
            }

        }
    }

}