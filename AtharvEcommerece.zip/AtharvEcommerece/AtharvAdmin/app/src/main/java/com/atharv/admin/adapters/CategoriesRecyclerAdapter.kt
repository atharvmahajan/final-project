package com.atharv.admin.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.atharv.admin.databinding.CategoriesRecItemDesignBinding
import com.atharv.admin.model.Categories
import java.text.SimpleDateFormat
import java.util.Locale

class CategoriesRecyclerAdapter(
    private val itemList: List<Categories>,
    private val listener: OnItemClickListener,
    private val context: Context
) :
    RecyclerView.Adapter<CategoriesRecyclerAdapter.CategoriesViewHolder>() {

    private val listData: MutableList<Categories> = itemList as MutableList<Categories>

    interface OnItemClickListener {
        fun actionDeleteCategory(item: Categories, position: Int)
        fun actionEditCategory(item: Categories, position: Int)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoriesViewHolder {
        val binding =
            CategoriesRecItemDesignBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        return CategoriesViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CategoriesViewHolder, position: Int) {
        val currentItem = listData[position]
        holder.bind(currentItem)
    }

    override fun getItemCount() = listData.size

    inner class CategoriesViewHolder(private val binding: CategoriesRecItemDesignBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: Categories) {
            binding.apply {

//                Picasso.get().load(item.image).into(imageView)
                Glide.with(context).load(item.image).into(imageView)
                nameTv.text = item.name
                val dateFormatted = item.time?.let {
                    SimpleDateFormat(
                        "dd MMM yy. hh:mm a",
                        Locale.getDefault()
                    ).format(it)
                }

                deleteActionIv.setOnClickListener {
                    val position = adapterPosition
                    if (position != RecyclerView.NO_POSITION) {
                        val clickedItem = itemList[position]
                        listener.actionDeleteCategory(item, position)
                    }
//                    deleteItem(position)
                }
                editActionIv.setOnClickListener {
                    val position = adapterPosition
                    if (position != RecyclerView.NO_POSITION) {
                        val clickedItem = itemList[position]
                        listener.actionEditCategory(clickedItem, position)
                    }
                }
            }


        }
    }

    fun deleteItem(index: Int) {
        listData.removeAt(index)
        notifyDataSetChanged()
    }
}