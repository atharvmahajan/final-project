package com.atharv.seller.adapters

import android.content.Context
import android.net.Uri
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.atharv.seller.R
import com.atharv.seller.databinding.ItemDynamicBinding

class DynamicImageViewAdapter(
    private val itemList: MutableList<Uri>,
    private val listener: OnItemClickListener,
    private val context: Context

) :
    RecyclerView.Adapter<DynamicImageViewAdapter.DynamicViewHolder>() {

    //Create click listener for view
    interface OnItemClickListener {
        fun onItemClick(item: Uri)
        fun onClearItemClick(position: Int)
    }

    // Create the view holder
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DynamicViewHolder {
        val viewBinding =
            ItemDynamicBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return DynamicViewHolder(viewBinding)
    }

    // Bind the data to the view holder
    override fun onBindViewHolder(holder: DynamicViewHolder, position: Int) {
        val item = itemList[position]
        holder.bind(item)
    }

    // Return the number of items in the list
    override fun getItemCount(): Int {
        return itemList.size
    }

    // Define the view holder
    inner class DynamicViewHolder(private val binding: ItemDynamicBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: Uri) {

            binding.apply {
                Glide
                    .with(context)
                    .load(item)
                    .placeholder(R.drawable.picture)
                    .into(binding.imageView)
                Log.d("DynamicViewHolder", "bind: $item")

                root.setOnClickListener {
                    val position = adapterPosition
                    if (position != RecyclerView.NO_POSITION) {
                        val clickedItem = itemList[position]
                        listener.onItemClick(clickedItem)
                    }
                }

                clearImageClick.setOnClickListener {
                    val position = adapterPosition
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onClearItemClick(position)
                    }
                }
            }

        }
    }
}
