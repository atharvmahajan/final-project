package com.atharv.admin.model

import java.io.Serializable

data class Admin(
    val email: String? = null,
    val password: String? = null
): Serializable
