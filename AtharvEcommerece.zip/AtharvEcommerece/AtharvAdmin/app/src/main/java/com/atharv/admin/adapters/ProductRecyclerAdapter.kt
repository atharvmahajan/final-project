package com.atharv.admin.adapters

import android.content.Context
import android.text.SpannableStringBuilder
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.text.bold
import androidx.core.text.color
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.atharv.admin.R
import com.atharv.admin.databinding.ProductsListLayoutBinding
import com.atharv.admin.model.Products
import java.text.SimpleDateFormat
import java.util.*

class ProductRecyclerAdapter(
    private val itemList: List<Products>,
    private val listener: OnItemClickListener,
    private val context: Context
) :
    RecyclerView.Adapter<ProductRecyclerAdapter.ProductsViewHolder>() {

    interface OnItemClickListener {
        fun onItemClick(item: Products)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductsViewHolder {
        val binding =
            ProductsListLayoutBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ProductsViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProductsViewHolder, position: Int) {
        val currentItem = itemList[position]
        holder.bind(currentItem)
    }

    override fun getItemCount() = itemList.size

    inner class ProductsViewHolder(private val binding: ProductsListLayoutBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: Products) {
            binding.apply {

//                Picasso.get().load(item.imageUri).into(productIv)
                Glide.with(context).load(item.images?.get(0)).into(binding.productIv)
                titleTv.text = item.title
                val priceString = SpannableStringBuilder()
                    .append("$")
                    .bold { append("${item.price}") }

                priceTv.text = priceString
                val dateFormatted = item.time?.let {
                    SimpleDateFormat(
                        "dd MMM yy. hh:mm a",
                        Locale.getDefault()
                    ).format(it)
                }

                val myCustomizedString = SpannableStringBuilder()
                    .append(dateFormatted)
                    .append(". ")
                    .color(context.resources.getColor(R.color.black)) { bold { append("${item.views}") } }
                    .append(" Views")


//                val s = "$dateFormatted.  101 Views"
                timeTv.text = myCustomizedString
                statusTv.setTextColor(context.resources.getColor(R.color.red))
                if (item.status == "Pending") {
                    statusTv.setTextColor(context.resources.getColor(R.color.red))
                } else {
                    statusTv.setTextColor(context.resources.getColor(R.color.green))
                }
                statusTv.text = item.status

                root.setOnClickListener {
                    val position = adapterPosition
                    if (position != RecyclerView.NO_POSITION) {
                        val clickedItem = itemList[position]
                        listener.onItemClick(clickedItem)
                    }
                }
            }


        }
    }
}