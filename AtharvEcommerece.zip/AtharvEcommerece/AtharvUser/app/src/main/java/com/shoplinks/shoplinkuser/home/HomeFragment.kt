package com.shoplinks.shoplinkuser.home

import android.os.Bundle
import android.text.SpannableStringBuilder
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.text.bold
import androidx.core.view.isVisible
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.shoplinks.shoplinkuser.R
import com.shoplinks.shoplinkuser.adapters.BannersListAdapter
import com.shoplinks.shoplinkuser.adapters.CategoriesRecAdapter
import com.shoplinks.shoplinkuser.adapters.HomeCategoriesRecyclerAdapter
import com.shoplinks.shoplinkuser.adapters.ProductRecyclerAdapter
import com.shoplinks.shoplinkuser.databinding.BottomsheetAddCartItemLayoutBinding
import com.shoplinks.shoplinkuser.databinding.CategoryBottomSheetLayoutBinding
import com.shoplinks.shoplinkuser.databinding.FragmentHomeBinding
import com.shoplinks.shoplinkuser.db.CartItem
import com.shoplinks.shoplinkuser.db.ShopLinkDatabase
import com.shoplinks.shoplinkuser.model.Banners
import com.shoplinks.shoplinkuser.model.Categories
import com.shoplinks.shoplinkuser.model.CategoryItem
import com.shoplinks.shoplinkuser.model.HeaderItem
import com.shoplinks.shoplinkuser.model.ListItem
import com.shoplinks.shoplinkuser.model.Products
import com.shoplinks.shoplinkuser.utils.Constants
import com.shoplinks.shoplinkuser.utils.DbConstants
import com.shoplinks.shoplinkuser.utils.toast
import com.zhpan.indicator.enums.IndicatorSlideMode
import com.zhpan.indicator.enums.IndicatorStyle
import kotlinx.coroutines.launch

class HomeFragment : BaseFragment(), ProductRecyclerAdapter.OnItemClickListener {

    companion object {

        const val TAG = "HomeFragment"
    }

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val productsList = mutableListOf<Products>()
    private val categoriesList = mutableListOf<Categories>()
    private val bannersList = mutableListOf<Banners>()

    private lateinit var db: FirebaseFirestore

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val view = binding.root
        db = Firebase.firestore

        hideProgressBar()
        fetchBanners()
        getCategories()
        fetchProducts(null)

//        binding.categorySelectionTv.setOnClickListener {
//            showCategoryBottomSheet()
//        }
        return view
    }


    private fun fetchBanners() {

        val docRef = db.collection(DbConstants.BANNERS)
        docRef.orderBy("time", Query.Direction.DESCENDING).get().addOnSuccessListener {


            bannersList.clear()
            for (document in it!!) {
                val banner = document.toObject(Banners::class.java)
                bannersList.add(banner)
            }

            val adapter = BannersListAdapter()
            binding.bannersSlider.adapter = adapter
            adapter.submitList(bannersList)

            binding.indicatorView.apply {
//            setSliderColor(normalColor, checkedColor)
                setSliderWidth(resources.getDimension(R.dimen.dp_10))
                setSliderHeight(resources.getDimension(R.dimen.dp_5))
                setSlideMode(IndicatorSlideMode.WORM)
                setIndicatorStyle(IndicatorStyle.CIRCLE)
                setupWithViewPager(binding.bannersSlider)
            }


        }.addOnFailureListener {
            requireContext().toast(it.message.toString())
            Log.e(SupportFragment.TAG, "fetchBanners: ${it.message.toString()}")
            binding.bannersSliderContainer.isVisible = false
        }

    }

    private fun getCategories() {
        val docRef = db.collection(DbConstants.CATEGORIES)
        docRef.orderBy("time", Query.Direction.DESCENDING).addSnapshotListener { value, error ->
            if (error != null) {
                requireContext().toast(error.message.toString())
                Log.e(SupportFragment.TAG, "getCategories: ${error.message.toString()}")
                return@addSnapshotListener
            }

            categoriesList.clear()
            for (document in value!!) {
                val category = document.toObject(Categories::class.java)
                categoriesList.add(category)
            }


            binding.homeCategoriesRv.adapter = HomeCategoriesRecyclerAdapter(
                categoriesList,
                requireContext(),
                object : HomeCategoriesRecyclerAdapter.OnItemClickListener {
                    override fun onSelectCategory(item: Categories, position: Int) {
                        val categoryName = item.name
//                        binding.categorySelectionTv.text = categoryName
                        fetchProducts(categoryName)
//                        dialog.dismiss()
                    }
                })

        }

    }

    private fun fetchProducts(category: String?) {

        binding.noDataFoundIv.isVisible = false
        productsList.clear()
        showProgressBar()
        val docRef = db.collection(DbConstants.PRODUCTS)

        var query: Query = if (category != null) {

            docRef.whereEqualTo("category", category)
                .whereEqualTo(Constants.STATUS_KEY, Constants.APPROVED)

        } else {
            docRef.whereEqualTo(Constants.STATUS_KEY, Constants.APPROVED)

        }

        query.get()

            .addOnSuccessListener { result ->
                if (!result.isEmpty) {
                    for (document in result) {
                        Log.d(TAG, "${document.id} => ${document.data}")
                        val products = document.toObject(Products::class.java)
                        productsList.add(products)
                    }

                    initRecyclerView()

                    Toast.makeText(
                        context,
                        "Products fetched.",
                        Toast.LENGTH_SHORT,
                    ).show()
                } else {
                    Toast.makeText(
                        context,
                        "Failed to fetch products",
                        Toast.LENGTH_SHORT,
                    ).show()
                    initRecyclerView()

                }
                hideProgressBar()
            }.addOnFailureListener { exception ->
                Log.d(TAG, "Error getting documents: ", exception)
                Toast.makeText(
                    context,
                    exception.message.toString(),
                    Toast.LENGTH_SHORT,
                ).show()

                hideProgressBar()
                initRecyclerView()

            }


    }

    private fun initRecyclerView() {
        binding?.let {
            if (productsList.isNotEmpty()) {
                it.noDataFoundIv.isVisible = false
                it.recyclerView.isVisible = true

                it.recyclerView.adapter =
                    ProductRecyclerAdapter(productsList, this, requireContext())

            } else {
                it.noDataFoundIv.isVisible = true
                it.recyclerView.isVisible = false
            }
        }

    }

    private fun hideProgressBar() {
        binding.apply {
            progressBar.root.isVisible = false
        }
    }

    private fun showProgressBar() {
        binding.apply {
            progressBar.root.isVisible = true
        }
    }

    override fun onItemClick(item: Products) {

        val db = Firebase.firestore
        val dbRef = db.collection(DbConstants.PRODUCTS).document(item.productId!!)

        db.runTransaction { transaction ->
            val snapshot = transaction.get(dbRef)
            val newViews = snapshot.getLong("views")!! + 1

            transaction.update(dbRef, "views", newViews)

        }.addOnSuccessListener { result ->
            Log.d(TAG, "Transaction success: $result")
        }.addOnFailureListener { e ->
            Log.w(TAG, "Transaction failure.", e)
        }


        val action = HomeFragmentDirections.actionHomeFragToProductDetailFrag(item)
        findNavController().navigate(action)


    }

    override fun onCartClick(item: Products) {
        showCartBottomSheet(item)
    }

    override fun onSellerLocationClick(item: Products) {

    }

    private fun showCartBottomSheet(item: Products) {

        // on below line we are creating a new bottom sheet dialog.
        val dialog = BottomSheetDialog(requireContext())

        // on below line we are inflating a layout file which we have created.
        val view =
            BottomsheetAddCartItemLayoutBinding.inflate(LayoutInflater.from(requireContext()))
        dialog.setContentView(view.root)

        view.apply {


            launch {
                context?.let { it ->
                    val cartItem =
                        ShopLinkDatabase(it).getCartItemDao().getCartItem(item.productId!!)

                    cartItem?.let {
                        itemCountTv.text = it.quantity
                    } ?: let {
                        itemCountTv.text = "1"

                    }
                }
            }

            Glide.with(requireContext()).load(item.images?.get(0)).into(imageView)
            titleTv.text = item.title
            val priceString = SpannableStringBuilder().append("$").bold { append("${item.price}") }
            priceTv.text = priceString

            addItemCount.setOnClickListener {

                var count = itemCountTv.text.toString().toInt()
                ++count
                itemCountTv.text = count.toString()

            }

            minusItemCount.setOnClickListener {

                var count = itemCountTv.text.toString().toInt()

                if (count > 0) {
                    --count
                    itemCountTv.text = count.toString()
                }
            }

            addToCart.setOnClickListener {
                dialog.cancel()

                launch {

                    context?.let {
                        val cartItem = CartItem(
                            item.productId!!,
                            item.title!!,
                            item.price!!,
                            itemCountTv.text.toString(),
                            item.images!![0]
                        )
                        ShopLinkDatabase(it).getCartItemDao().addCartItem(cartItem)
                        it.toast("Added to cart")
                    }

                }

            }
        }


        dialog.show()

    }

    private fun showCategoryBottomSheet() {

        // on below line we are creating a new bottom sheet dialog.
        val dialog = BottomSheetDialog(requireContext())

        // on below line we are inflating a layout file which we have created.
        val view = CategoryBottomSheetLayoutBinding.inflate(LayoutInflater.from(requireContext()))
        dialog.setContentView(view.root)

        view.apply {

            recyclerView.adapter = CategoriesRecAdapter(
                categoriesList,
                requireContext(),
                object : CategoriesRecAdapter.OnItemClickListener {
                    override fun onSelectCategory(item: Categories, position: Int) {
                        val categoryName = item.name
//                        binding.categorySelectionTv.text = categoryName
                        fetchProducts(categoryName)
                        dialog.dismiss()
                    }
                })

            allCategoryBtn.setOnClickListener {
//                binding.categorySelectionTv.text = getString(R.string.all_categories)
                fetchProducts(null)
                dialog.dismiss()
            }
        }

        dialog.show()

    }


}

