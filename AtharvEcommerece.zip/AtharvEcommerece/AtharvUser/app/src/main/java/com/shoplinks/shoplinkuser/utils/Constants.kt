package com.shoplinks.shoplinkuser.utils

object Constants {

    const val USER_TYPE = "Customer"
    const val PENDING = "Pending"
    const val APPROVED = "Approved"
    const val STATUS_KEY = "status"
}