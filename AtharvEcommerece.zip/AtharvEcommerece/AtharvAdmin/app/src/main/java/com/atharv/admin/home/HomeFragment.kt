package com.atharv.admin.home

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.atharv.admin.R
import com.atharv.admin.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {

    companion object {
        const val TAG = "HomeFragment"
    }

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val db = Firebase.firestore

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)

        setUpClickListeners()
        return binding.root
    }

    private fun setUpClickListeners() {

        binding.apply {

            approvalCv.setOnClickListener {
                findNavController().navigate(R.id.action_homeFrag_to_approveProductsFrag)
            }
            productCv.setOnClickListener {
                findNavController().navigate(R.id.action_homeFrag_to_productsFrag)
            }
            categoriesCv.setOnClickListener {
                findNavController().navigate(R.id.action_home_to_categories)
            }
            bannersCv.setOnClickListener {
                findNavController().navigate(R.id.action_homeFrag_to_bannersFrag)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}