package com.shoplinks.shoplinkuser.home

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.widget.SearchView
import androidx.core.view.MenuProvider
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.navigation.fragment.findNavController
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.shoplinks.shoplinkuser.R
import com.shoplinks.shoplinkuser.adapters.ProductRecyclerAdapter
import com.shoplinks.shoplinkuser.adapters.SearchRecyclerAdapter
import com.shoplinks.shoplinkuser.databinding.FragmentSearchBinding
import com.shoplinks.shoplinkuser.model.Categories
import com.shoplinks.shoplinkuser.model.Products
import com.shoplinks.shoplinkuser.utils.Constants
import com.shoplinks.shoplinkuser.utils.DbConstants

class SearchFragment : Fragment(), SearchRecyclerAdapter.OnItemClickListener,
    ProductRecyclerAdapter.OnItemClickListener {
    companion object {
        const val TAG = "SearchFragment"
    }

    private var _binding: FragmentSearchBinding? = null

    //    private val binding get() = _binding!!
    private val categoriesList = mutableListOf<String>()
    private val productsList = mutableListOf<Products>()
    private lateinit var db: FirebaseFirestore


    @SuppressLint("RestrictedApi")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentSearchBinding.inflate(inflater, container, false)
        db = Firebase.firestore

        fetchCategories()
        setToolbarMenu()

        return _binding?.root
    }

    private fun searchSubstringInList(substring: String) {
        Log.i(TAG, "searchSubstringInList: $categoriesList")
        val filteredList = categoriesList.filter { it.contains(substring, ignoreCase = true) }
        Log.i(TAG, "searchSubstringInList: ${filteredList.toString()}")
        val searchAdapter = SearchRecyclerAdapter(filteredList, requireContext(), this)
        _binding?.apply {
            searchRv.apply {
                isVisible = true
                adapter = searchAdapter
                searchAdapter.notifyDataSetChanged()
            }

        }
    }

    private fun fetchCategories() {

        val db = Firebase.firestore
        val docRef = db.collection(DbConstants.CATEGORIES)
        docRef
            .get()
            .addOnSuccessListener { result ->
                if (!result.isEmpty) {
                    for (document in result) {
                        Log.d(HomeFragment.TAG, "${document.id} => ${document.data}")
                        val category = document.toObject(Categories::class.java)
                        categoriesList.add(category.name!!)
                    }

                } else {
                    Log.i(TAG, "fetchCategories: empty")
                }
            }.addOnFailureListener { exception ->
                Log.d(HomeFragment.TAG, "Error getting documents: ", exception)
            }
    }

    private fun setToolbarMenu() {
        activity?.addMenuProvider(object : MenuProvider {

            override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
                menuInflater?.inflate(R.menu.search_frag_menu, menu)
                val searchView =
                    ((context as HomeActivity).supportActionBar?.themedContext ?: context)?.let {
                        SearchView(
                            it
                        )
                    }
                menu.findItem(R.id.action_search).apply {
                    setShowAsAction(MenuItem.SHOW_AS_ACTION_COLLAPSE_ACTION_VIEW or MenuItem.SHOW_AS_ACTION_IF_ROOM)
                    actionView = searchView

                    setOnActionExpandListener(object : MenuItem.OnActionExpandListener {
                        override fun onMenuItemActionExpand(p0: MenuItem?): Boolean {
//                            binding.searchRv.isVisible = true
                            return true
                        }

                        override fun onMenuItemActionCollapse(p0: MenuItem?): Boolean {
                            _binding?.searchRv?.isVisible = false
                            return true
                        }

                    })
                }

                searchView?.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
                    override fun onQueryTextSubmit(query: String): Boolean {
                        searchSubstringInList(query)
                        return false
                    }

                    override fun onQueryTextChange(newText: String): Boolean {

                        if (newText.isNotEmpty()) {
                            searchSubstringInList(newText)
                        } else {
                            _binding?.apply {
                                searchRv.isVisible = false
                            }
                        }

                        return false
                    }
                })
//                searchView?.setOnClickListener {view ->  }

//                val closeBtn: View =
//                    searchView?.findViewById(androidx.appcompat.R.id.search_close_btn)!!
//                closeBtn.setOnClickListener {
//                    searchView.setQuery("", false) // reset Query text to be empty without submition
////                    searchView.isIconified = true // Replace the x icon with the search icon
//                    _binding?.searchRv.isVisible = false
//                }

            }

            override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
                return false
            }
        }, viewLifecycleOwner, Lifecycle.State.RESUMED)
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun selectCategory(name: String?) {

        _binding?.searchRv?.isVisible = false
        fetchProducts(name)

    }

    private fun fetchProducts(category: String?) {

//        _binding?.noDataFoundIv.isVisible = false
        productsList.clear()
        showProgressBar()
        val docRef = db.collection(DbConstants.PRODUCTS)

        docRef.whereEqualTo("category", category)
            .whereEqualTo(Constants.STATUS_KEY, Constants.APPROVED)
            .get()

            .addOnSuccessListener { result ->
                if (!result.isEmpty) {
                    for (document in result) {
                        Log.d(HomeFragment.TAG, "${document.id} => ${document.data}")
                        val products = document.toObject(Products::class.java)
                        productsList.add(products)
                    }

                    initRecyclerView()

                    Toast.makeText(
                        context,
                        "Products fetched.",
                        Toast.LENGTH_SHORT,
                    ).show()
                } else {
                    Toast.makeText(
                        context,
                        "Failed to fetch products",
                        Toast.LENGTH_SHORT,
                    ).show()
                    initRecyclerView()

                }
                hideProgressBar()
            }.addOnFailureListener { exception ->
                Log.d(HomeFragment.TAG, "Error getting documents: ", exception)
                Toast.makeText(
                    context,
                    exception.message.toString(),
                    Toast.LENGTH_SHORT,
                ).show()

                hideProgressBar()
                initRecyclerView()

            }


    }

    private fun initRecyclerView() {
        _binding?.let {
            if (productsList.isNotEmpty()) {
                it.messageLayout.isVisible = false
                it.productRv.isVisible = true

                it.productRv.adapter =
                    ProductRecyclerAdapter(productsList, this, requireContext())

            } else {
                it.messageLayout.isVisible = true
                it.productRv.isVisible = false
            }
        }

    }

    private fun hideProgressBar() {
        _binding?.apply {
//            progressBar.root.isVisible = false
        }
    }

    private fun showProgressBar() {
        _binding?.apply {
//            progressBar.root.isVisible = true
        }
    }

    override fun onItemClick(item: Products) {

        val db = Firebase.firestore
        val dbRef = db.collection(DbConstants.PRODUCTS).document(item.productId!!)

        db.runTransaction { transaction ->
            val snapshot = transaction.get(dbRef)
            val newViews = snapshot.getLong("views")!! + 1

            transaction.update(dbRef, "views", newViews)

        }.addOnSuccessListener { result ->
            Log.d(HomeFragment.TAG, "Transaction success: $result")
        }.addOnFailureListener { e ->
            Log.w(HomeFragment.TAG, "Transaction failure.", e)
        }


        val action = SearchFragmentDirections.actionSearchToProductDetail(item)
        findNavController().navigate(action)


    }

    override fun onCartClick(item: Products) {
    }

    override fun onSellerLocationClick(item: Products) {

    }
}