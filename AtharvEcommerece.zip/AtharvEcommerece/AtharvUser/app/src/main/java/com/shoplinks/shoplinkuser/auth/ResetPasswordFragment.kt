package com.shoplinks.shoplinkuser.auth

import android.app.AlertDialog
import android.content.DialogInterface
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.google.firebase.auth.FirebaseAuth
import com.shoplinks.shoplinkuser.databinding.FragmentResetPasswordBinding


class ResetPasswordFragment : Fragment() {

    companion object {
        const val TAG = "ResetPasswordFragment"
    }

    private var _binding: FragmentResetPasswordBinding? = null

    // This property is only valid between onCreateView and
// onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentResetPasswordBinding.inflate(inflater, container, false)
        val view = binding.root
        hideProgressBar()
        setClickListeners()

        return view
    }

    private fun setClickListeners() {

        binding.apply {
            sendBtn.setOnClickListener {

                validateViews()
            }


            backButton.setOnClickListener {
                findNavController().popBackStack()
            }
        }

    }

    private fun validateViews() {

        binding.apply {

            val email = emailEt.text.toString().trim()

            if (email.isEmpty()) {
                emailInputLayout.error = "Email can not be blank"
            } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                emailInputLayout.error = "Email is invalid"
            } else {
                resetPassword(email)
            }
        }
    }

    private fun resetPassword(email: String) {
        showProgressBar()
        FirebaseAuth.getInstance().sendPasswordResetEmail(email)
            .addOnCompleteListener { task ->

                if (task.isSuccessful) {
                    Log.d(TAG, "Email sent.")
                    binding.emailEt.setText("")
                    displayAlertDialog()
                } else {
                    Log.d(TAG, "resetPassword: ${task.exception?.message.toString()}")
                    Toast.makeText(
                        context,
                        task.exception?.message.toString(),
                        Toast.LENGTH_SHORT,
                    ).show()
                }
                hideProgressBar()
            }.addOnFailureListener {
                Log.d(TAG, "resetPassword: ${it.message.toString()}")
                Toast.makeText(
                    context,
                    it.message.toString(),
                    Toast.LENGTH_SHORT,
                ).show()
                hideProgressBar()
            }

    }

    private fun displayAlertDialog() {

        AlertDialog.Builder(requireContext())
            .setTitle("Confirmation!")
            .setMessage("Please check your email. Reset password link is sent at your email")
            .setCancelable(false)
            .setPositiveButton("Close", DialogInterface.OnClickListener { dialog, id ->
                dialog.cancel()
            })
            .create()
            .show()
    }

    private fun hideProgressBar() {
        binding.apply {
            progressBar.isVisible = false
            sendBtn.isVisible = true
        }
    }

    private fun showProgressBar() {
        binding.apply {
            progressBar.isVisible = true
            sendBtn.isVisible = false
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}