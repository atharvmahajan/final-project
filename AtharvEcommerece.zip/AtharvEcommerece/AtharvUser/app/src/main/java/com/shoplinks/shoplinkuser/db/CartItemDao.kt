package com.shoplinks.shoplinkuser.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface CartItemDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addCartItem(cartItem: CartItem)

    @Query("SELECT * FROM cartItem")
    suspend fun getAllCartItems(): List<CartItem>

    @Query("SELECT * FROM cartItem WHERE productId = :id")
    suspend fun getCartItem(id: String): CartItem?

    @Query("DELETE FROM CartItem")
    suspend fun delete()
}