package com.shoplinks.shoplinkuser.home

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.shoplinks.shoplinkuser.auth.AuthActivity
import com.shoplinks.shoplinkuser.auth.SignInFragment
import com.shoplinks.shoplinkuser.databinding.FragmentProfileBinding
import com.shoplinks.shoplinkuser.model.Users
import com.shoplinks.shoplinkuser.utils.DbConstants

class ProfileFragment : Fragment() {
    companion object {
        const val TAG = "ProfileFragment"
    }

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        val view = binding.root

        fetchUser()
        setClickListeners()

        return view
    }

    private fun fetchUser() {
        val db = Firebase.firestore
        val auth = Firebase.auth
        val currentUser = auth.currentUser

        db.collection(DbConstants.USERS)
            .document(currentUser!!.uid)
            .get()
            .addOnSuccessListener { result ->

                if (result.exists()){
                    Log.d(SignInFragment.TAG, "${result.id} => ${result.data}")

                    val user = result.toObject(Users::class.java)
                    updateUI(user)
                }



            }
            .addOnFailureListener { exception ->
                Log.w(SignInFragment.TAG, "Error getting documents.", exception)
                updateUI(null)
                Toast.makeText(
                    context,
                    exception.message.toString(),
                    Toast.LENGTH_SHORT,
                ).show()
            }

    }

    private fun updateUI(user: Users?) {

        user?.let {
            binding.apply {
                nameTv.text = user.userName
                nameTv.isAllCaps = true
                emailTv.text = user.email
                locationTv.text = user.location
            }
        }


    }

    private fun setClickListeners() {
        binding.apply {
            logoutBtn.setOnClickListener {
                Firebase.auth.signOut()
                activity?.let {
                    startActivity(Intent(it, AuthActivity::class.java))
                    requireActivity().finish()
                }
            }
        }

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}