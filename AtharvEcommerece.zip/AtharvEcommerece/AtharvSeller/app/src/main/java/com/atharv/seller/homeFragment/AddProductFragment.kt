package com.atharv.seller.homeFragment

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.github.dhaval2404.imagepicker.ImagePicker
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.storage.FirebaseStorage
import com.atharv.seller.PaymentActivity
import com.atharv.seller.adapters.CategoriesRecyclerAdapter
import com.atharv.seller.adapters.DynamicImageViewAdapter
import com.atharv.seller.utils.DbConstants
import com.atharv.seller.databinding.CategoryBottomSheetLayoutBinding
import com.atharv.seller.databinding.FragmentAddProductBinding
import com.atharv.seller.model.Categories
import com.atharv.seller.model.Users
import com.atharv.seller.utils.showToast
import kotlinx.coroutines.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class AddProductFragment : Fragment(), DynamicImageViewAdapter.OnItemClickListener {
    companion object {
        const val TAG = "AddProductFragment"
    }

    private var _binding: FragmentAddProductBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: DynamicImageViewAdapter
    private var recItemsList = mutableListOf<Uri>()
    private var productImages = mutableListOf<Uri>()
    private lateinit var imageUri: Uri
    private lateinit var db: FirebaseFirestore
    private lateinit var docRef: CollectionReference
    private lateinit var usersDocRef: CollectionReference
    private val categoriesList = mutableListOf<Categories>()


    private val startForProfileImageResult =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->
            val resultCode = result.resultCode
            val data = result.data

            when (resultCode) {
                Activity.RESULT_OK -> {
                    //Image Uri will not be null for RESULT_OK
                    val fileUri = data?.data!!
                    imageUri = fileUri
                    productImages.add(imageUri)
                    recItemsList.add(imageUri)

//                    initImagesRec()
                    adapter.notifyItemInserted(recItemsList.count() - 1)
                    binding.addImgTv.text = if(productImages.size > 0)  "Add More Images" else "Add Image"

                    Log.d(TAG, "productImages: $productImages")
                    Log.d(TAG, "recItemsList: $recItemsList")

                }

                ImagePicker.RESULT_ERROR -> {
                    Toast.makeText(context, ImagePicker.getError(data), Toast.LENGTH_SHORT).show()
                }

                else -> {
                    Toast.makeText(context, "Task Cancelled", Toast.LENGTH_SHORT).show()
                }
            }
        }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentAddProductBinding.inflate(inflater, container, false)
        val view = binding.root

        db = Firebase.firestore
        docRef = db.collection(DbConstants.CATEGORIES)
        usersDocRef = db.collection(DbConstants.USERS)

        hideProgressbar()
        setClickListeners()
        initImagesRec()
        getCategories()
        return view
    }

    private fun initImagesRec() {
        productImages = mutableListOf()
        adapter = DynamicImageViewAdapter(recItemsList, this, requireContext())
        binding.imagesRecycler.adapter = adapter
    }

    private fun createImageUri(): Uri? {
        val dateFormat = SimpleDateFormat("yyyyMMddHHmmss", Locale.getDefault())
        val currentTimeStamp: String = dateFormat.format(Date())
        val image =
            File(activity?.applicationContext?.filesDir, "shoplink_photo$currentTimeStamp.png")

        return FileProvider.getUriForFile(
            activity?.applicationContext!!,
            "com.shoplinks.seller.fileProvider",
            image
        )
    }

    private fun setClickListeners() {

        binding.apply {
            pickPhotoClick.setOnClickListener {
//                imageUri = createImageUri()!!
//                contract.launch(imageUri)

                ImagePicker.with(this@AddProductFragment)
                    .compress(1024)         //Final image size will be less than 1 MB(Optional)
                    .maxResultSize(
                        1080,
                        1080
                    )  //Final image resolution will be less than 1080 x 1080(Optional)
                    .crop(16f, 10f)
                    .createIntent { intent ->
                        startForProfileImageResult.launch(intent)
                    }
            }

            categorySelectionTv.setOnClickListener {
                showCategoryBottomSheet()
            }

            postButton.setOnClickListener {
                validateViews()
            }
        }
    }

    private fun validateViews() {
//        postProduct()

        binding.apply {
            if (productImages.isEmpty()) {
                Toast.makeText(context, "You didn't select photo", Toast.LENGTH_SHORT).show()
            } else if (titleEt.text.toString().trim().isEmpty()) {
                Toast.makeText(context, "Title can not be blank", Toast.LENGTH_SHORT).show()
            } else if (priceEt.text.toString().trim().isEmpty()) {
                Toast.makeText(context, "Price can not be blank", Toast.LENGTH_SHORT).show()
            } else if (categorySelectionTv.text.toString().trim().isEmpty()) {
                Toast.makeText(context, "Category can not be blank", Toast.LENGTH_SHORT).show()
            } else if (descriptionEt.text.toString().trim().isEmpty()) {
                Toast.makeText(context, "Description can not be blank", Toast.LENGTH_SHORT).show()
            } else {
                postProduct()
            }
        }

    }

    private fun postProduct() {
        showProgressbar()

        binding.apply {

            val storageRef = FirebaseStorage.getInstance().reference
            val downloadURLsList = mutableListOf<String>()
            val db = Firebase.firestore
            val dbRef = db.collection(DbConstants.PRODUCTS).document()
            val productId = dbRef.id

            val title = titleEt.text.toString().trim()
            val price = priceEt.text.toString().trim()
            val category = categorySelectionTv.text.toString().trim()
            val description = descriptionEt.text.toString().trim()

            val productMap = hashMapOf(
                "title" to title,
                "price" to price,
                "category" to category,
                "description" to description,
                "time" to FieldValue.serverTimestamp(),
                "status" to "Pending",
                "sellerId" to Firebase.auth.currentUser!!.uid,
                "productId" to productId,
                "views" to 0,
            )




            CoroutineScope(Dispatchers.IO).launch {

                dbRef
                    .set(productMap)
                    .addOnSuccessListener { documentReference ->
//                        Log.d(TAG, "DocumentSnapshot added with ID: ${documentReference.id}")
//                        productId = documentReference.id

                        for (imageUri in productImages) {

                            val imageRef = storageRef.child("products/${imageUri.lastPathSegment}")
                            val uploadTask = imageRef.putFile(imageUri)
                            uploadTask.addOnSuccessListener {
                                // Image uploaded successfully
                                // You can get the download URL or perform further operations here
                                val downloadUrlTask = imageRef.downloadUrl
                                downloadUrlTask.addOnSuccessListener { downloadUri ->
                                    val imageUrl = downloadUri.toString()
                                    // Save the imageUrl to your database or perform other actions
                                    Log.d(TAG, "postProduct: $imageUrl")
                                    downloadURLsList.add(imageUrl)
                                    if (downloadURLsList.count() == productImages.count()) {
                                        db.collection(DbConstants.PRODUCTS)
                                            .document(productId)
                                            .update("images", downloadURLsList)
                                            .addOnSuccessListener {
                                                Toast.makeText(
                                                    context,
                                                    "Your product is posted.",
                                                    Toast.LENGTH_SHORT
                                                )
                                                    .show()
                                                // Subscribe to a topic
                                                FirebaseMessaging.getInstance()
                                                    .subscribeToTopic(category)

                                                updateSellerTopics(category)

                                                hideProgressbar()
                                                findNavController().popBackStack()
                                            }
                                            .addOnFailureListener { e ->
                                                Log.w(TAG, "Error adding document", e)
                                                Toast.makeText(
                                                    context,
                                                    e.message.toString(),
                                                    Toast.LENGTH_SHORT
                                                ).show()
                                                hideProgressbar()
                                            }

                                    }
                                }
                            }.addOnFailureListener { e ->
                                Log.w(TAG, "Error adding document", e)
                                Toast.makeText(context, e.message.toString(), Toast.LENGTH_SHORT)
                                    .show()
                                hideProgressbar()
                            }
                        }
                    }
                    .addOnFailureListener { e ->
                        Log.w(TAG, "Error adding document", e)
                        Toast.makeText(context, e.message.toString(), Toast.LENGTH_SHORT).show()
                        hideProgressbar()
                    }


            }

        }


    }

    private fun updateSellerTopics(category: String) {


        CoroutineScope(Dispatchers.IO).launch {

            usersDocRef
                .document(Firebase.auth.currentUser!!.uid)
                .get()
                .addOnSuccessListener {
                    val user = it.toObject(Users::class.java)
                    Log.d(TAG, "updateSellerTopics: $user")
                    user?.let { it1 ->
                        it1.topics?.let { it2 ->
                            if (!it2.contains(category)) {
                                val list = it2 as MutableList
                                list.add(category)
                                usersDocRef.document(Firebase.auth.currentUser!!.uid)
                                    .update(mapOf("topics" to list))
                            }
                        } ?: usersDocRef.document(Firebase.auth.currentUser!!.uid)
                            .update((mapOf("topics" to listOf(category))))


                    }

                }
        }

    }

    private fun showCategoryBottomSheet() {

        // on below line we are creating a new bottom sheet dialog.
        val dialog = BottomSheetDialog(requireContext())

        // on below line we are inflating a layout file which we have created.
//        val view = layoutInflater.inflate(R.layout.category_bottom_sheet_layout, null)
        val view = CategoryBottomSheetLayoutBinding.inflate(LayoutInflater.from(requireContext()))


//        var category: String

        view.apply {
            if (categoriesList.isNotEmpty()) {
                categoriesListRc.adapter = CategoriesRecyclerAdapter(
                    categoriesList,
                    requireContext(),
                    object : CategoriesRecyclerAdapter.OnItemClickListener {
                        override fun onSelectCategory(item: Categories, position: Int) {
                            binding.categorySelectionTv.text = item.name
                            dialog.dismiss()
                        }

                    })
            }
        }

        dialog.apply {
            setContentView(view.root)
            setCancelable(true)
            show()
        }

    }

    private fun hideProgressbar() {
        binding.apply {
            progressBar.isVisible = false
            postButton.isVisible = true
        }
    }

    private fun showProgressbar() {
        binding.apply {
            progressBar.isVisible = true
            postButton.isVisible = false
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onItemClick(item: Uri) {
//        imageUri = createImageUri()!!
//        contract.launch(imageUri)
    }

    override fun onClearItemClick(position: Int) {

        productImages.removeAt(position)
        recItemsList.removeAt(position)

        adapter.notifyItemRemoved(position)

        binding.addImgTv.text = if(productImages.size > 0) "Add More Images" else "Add Image"
    }

    private fun getCategories() {
        showProgressbar()
        docRef.orderBy("time", Query.Direction.DESCENDING).addSnapshotListener { value, error ->
            hideProgressbar()
            if (error != null) {
                showToast(requireContext(), error.message.toString())
                Log.e(TAG, "getCategories: ${error.message.toString()}")
                return@addSnapshotListener
            }

            categoriesList.clear()
            for (document in value!!) {
                val category = document.toObject(Categories::class.java)
                categoriesList.add(category)
            }

        }

    }


}