package com.shoplinks.shoplinkuser.home

import android.os.Bundle
import android.text.SpannableStringBuilder
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.text.bold
import androidx.core.text.color
import androidx.core.view.isVisible
import androidx.navigation.fragment.findNavController
import com.shoplinks.shoplinkuser.R
import com.shoplinks.shoplinkuser.adapters.CartItemsRecyclerAdapter
import com.shoplinks.shoplinkuser.databinding.FragmentCartBinding
import com.shoplinks.shoplinkuser.db.CartItem
import com.shoplinks.shoplinkuser.db.ShopLinkDatabase
import kotlinx.coroutines.launch

class CartFragment : BaseFragment(), CartItemsRecyclerAdapter.OnItemClickListener {
    companion object {
        const val TAG = "CartFragment"
    }

    private var _binding: FragmentCartBinding? = null
    private val binding get() = _binding!!
    private var cartItemsList = listOf<CartItem>()
    private var totalCost: Double = 0.0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentCartBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.bottomLayout.isVisible = false

        hideProgressBar()
        fetchCartItems()

        binding.checkoutBtn.setOnClickListener {
            /*if (cartItemsList.isNotEmpty()){
                val action = CartFragmentDirections.actionCartFragToCheckoutFrag(totalCost = totalCost.toString())
                findNavController().navigate(action)

            }*/
        }

    }

    private fun fetchCartItems() {

        launch {
            context?.let {
                showProgressBar()
                cartItemsList = ShopLinkDatabase(it).getCartItemDao().getAllCartItems()
                hideProgressBar()
                initRecyclerView()

            }
        }

    }

    private fun initRecyclerView() {

        if (cartItemsList.isNotEmpty()) {
            binding.bottomLayout.isVisible = true
            binding.cartItemsRecView.adapter =
                CartItemsRecyclerAdapter(cartItemsList, this, requireContext())

            cartItemsList.forEach {

                val subTotal = it.price.toDouble() * it.quantity.toDouble()
                totalCost += subTotal
            }

            val totalString = SpannableStringBuilder()
                .append("Total: $")
                .color(resources.getColor(R.color.black)){
                    bold { append(totalCost.toString()) }
                }



            binding.totalCostTv.text = totalString
        }
    }

    override fun onMinusClick(item: CartItem) {
    }

    override fun onPlusClick(item: CartItem) {
    }


    private fun hideProgressBar() {
        binding.apply {
            progressBar.root.isVisible = false
        }
    }

    private fun showProgressBar() {
        binding.apply {
            progressBar.root.isVisible = true
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}