package com.atharv.seller.utils

object Constants {

    const val USER_TYPE = "Seller"
}