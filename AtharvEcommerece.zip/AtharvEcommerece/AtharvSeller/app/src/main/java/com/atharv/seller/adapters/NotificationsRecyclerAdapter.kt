package com.atharv.seller.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.atharv.seller.databinding.NotificationItemLayoutBinding
import com.atharv.seller.model.Notifications
import com.atharv.seller.utils.getTimeAgo
import java.util.Date

class NotificationsRecyclerAdapter(
    private val itemList: List<Notifications>,
    private val listener: OnItemClickListener,
    private val context: Context
) :
    RecyclerView.Adapter<NotificationsRecyclerAdapter.ProductsViewHolder>() {

    interface OnItemClickListener {
        fun onItemClick(item: Notifications)
        fun onClickWhatsappIcon(item: Notifications)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductsViewHolder {
        val binding =
            NotificationItemLayoutBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        return ProductsViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProductsViewHolder, position: Int) {
        val currentItem = itemList[position]
        holder.bind(currentItem)
    }

    override fun getItemCount() = itemList.size

    inner class ProductsViewHolder(private val binding: NotificationItemLayoutBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: Notifications) {
            binding.apply {

                notificationTv.text = item.notificationMessage
                timeTv.text = Date().getTimeAgo(item.time)
                root.setOnClickListener {
                    val position = adapterPosition
                    if (position != RecyclerView.NO_POSITION) {
                        val clickedItem = itemList[position]
                        listener.onItemClick(clickedItem)
                    }
                }

                phoneBtn.setOnClickListener {
                    val position = adapterPosition
                    if (position != RecyclerView.NO_POSITION) {
                        val clickedItem = itemList[position]
                        listener.onClickWhatsappIcon(clickedItem)
                    }
                }
            }
        }
    }
}