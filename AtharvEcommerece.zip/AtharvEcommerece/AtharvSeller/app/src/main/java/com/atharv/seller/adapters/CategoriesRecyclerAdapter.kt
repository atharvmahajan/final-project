package com.atharv.seller.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.atharv.seller.databinding.CategoriesRecItemDesignBinding
import com.atharv.seller.model.Categories
import java.text.SimpleDateFormat
import java.util.Locale

class CategoriesRecyclerAdapter(
    private val itemList: List<Categories>,
    private val context: Context,
    private val listener: OnItemClickListener,
) :
    RecyclerView.Adapter<CategoriesRecyclerAdapter.CategoriesViewHolder>() {

    private val listData: MutableList<Categories> = itemList as MutableList<Categories>

    interface OnItemClickListener {
        fun onSelectCategory(item: Categories, position: Int)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoriesViewHolder {
        val binding =
            CategoriesRecItemDesignBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        return CategoriesViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CategoriesViewHolder, position: Int) {
        val currentItem = listData[position]
        holder.bind(currentItem)
    }

    override fun getItemCount() = listData.size

    inner class CategoriesViewHolder(private val binding: CategoriesRecItemDesignBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: Categories) {
            binding.apply {

//                Picasso.get().load(item.image).into(imageView)
                Glide.with(context).load(item.image).into(categoryIv)
                categoryNameTv.text = item.name
                val dateFormatted = item.time?.let {
                    SimpleDateFormat(
                        "dd MMM yy. hh:mm a",
                        Locale.getDefault()
                    ).format(it)
                }

                root.setOnClickListener {
                    val position = adapterPosition
                    if (position != RecyclerView.NO_POSITION) {
                        val clickedItem = itemList[position]
                        listener.onSelectCategory(item, position)
                    }
                }
            }

        }
    }

}