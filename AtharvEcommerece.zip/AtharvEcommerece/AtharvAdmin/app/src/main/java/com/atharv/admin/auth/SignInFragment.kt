package com.atharv.admin.auth

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.navigation.fragment.findNavController
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.atharv.admin.R
import com.atharv.admin.databinding.FragmentSignInBinding
import com.atharv.admin.home.HomeActivity
import com.atharv.admin.util.Constants
import com.atharv.admin.util.DbConstants


class SignInFragment : Fragment() {
    companion object {
        const val TAG = "SignInFragment"
    }

    private var _binding: FragmentSignInBinding? = null
    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    private val db = Firebase.firestore

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentSignInBinding.inflate(inflater, container, false)
        val view = binding.root

        hideProgressBar()
        setClickListeners()

        return view
    }

    private fun setClickListeners() {


        binding.apply {

            forgotPasswordTv.setOnClickListener {
                findNavController().navigate(R.id.action_signInFrag_to_resetPasswordFrag)
            }

            signUpBtn.setOnClickListener {
                findNavController().navigate(R.id.action_signInFrag_to_signUpFrag)
            }

            signInBtn.setOnClickListener {
                validateViews()
            }

            backButton.setOnClickListener {
                findNavController().popBackStack()
            }
        }


    }

    private fun validateViews() {

        binding.apply {

            val email = emailEt.text.toString().trim()
            val password = passwordEt.text.toString().trim()

            if (email.isEmpty()) {
                emailInputLayout.error = "Email can not be blank"
            } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                emailInputLayout.error = "Email is invalid"
            } else if (password.isEmpty()) {
                passwordInputLayout.error = "Password can not be blank"
            } else if (password.length < 8) {
                passwordInputLayout.error = "Use 8 characters or more for your password"
            } else {
                mapData()
            }
        }
    }

    private fun mapData() {

        binding.apply {
            val email = emailEt.text.toString().trim()
            val password = passwordEt.text.toString().trim()

            signInUser(email, password)
        }
    }

    private fun signInUser(email: String, password: String) {
        showProgressBar()
        val auth = Firebase.auth
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener {
                if (it.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    Log.d(TAG, "signInWithEmail:success")
                    val user = auth.currentUser

                    db.collection(DbConstants.ADMIN)
                        .document(user!!.uid)
                        .get()
                        .addOnSuccessListener { result ->

                            Log.d(TAG, "${result.id} => ${result.data}")
                            val userType = result.data?.get("userType")

                            if (userType == DbConstants.ADMIN){
                                updateUI(user)
                            }else {
                                auth.signOut()
                                updateUI(null)
                                Toast.makeText(
                                    context,
                                    "You are not registered as SELLER",
                                    Toast.LENGTH_SHORT,
                                ).show()
                            }
                        }
                        .addOnFailureListener { exception ->
                            Log.w(TAG, "Error getting documents.", exception)
                            updateUI(null)
                            Toast.makeText(
                                context,
                                exception.message.toString(),
                                Toast.LENGTH_SHORT,
                            ).show()
                        }
                } else {
                    // If sign in fails, display a message to the user.
                    Log.w(TAG, "signInWithEmail:failure", it.exception)
                    Toast.makeText(
                        context,
                        it.exception?.message.toString(),
                        Toast.LENGTH_SHORT,
                    ).show()
                    updateUI(null)
                }
            }
    }

    private fun updateUI(user: FirebaseUser?) {

        Constants.ADMIN_EMAIL = user?.email.toString()

        user?.let {
            activity?.let {
                startActivity(Intent(it, HomeActivity::class.java))
                requireActivity().finish()
            }
        }

        hideProgressBar()

    }

    private fun hideProgressBar() {
        binding.apply {
            progressBar.isVisible = false
            signInBtn.isVisible = true
        }
    }

    private fun showProgressBar() {
        binding.apply {
            progressBar.isVisible = true
            signInBtn.isVisible = false
        }
    }
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}