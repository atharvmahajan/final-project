package com.atharv.seller.homeFragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.navArgs
import com.atharv.seller.R
import com.atharv.seller.databinding.FragmentProductDetailBinding


class ProductDetailFragment : Fragment() {
    companion object {

    }

    private var _binding: FragmentProductDetailBinding? = null
    private val binding get() = _binding!!
    private val productArg: ProductDetailFragmentArgs by navArgs()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentProductDetailBinding.inflate(inflater, container, false)

        showProduct()
        return binding.root
    }

    private fun showProduct() {

        productArg.product?.let {

            activity?.actionBar?.title = it.title
            binding.apply {
//                Glide.with(this@ProductDetailFragment).load(it.imageUri).into(binding.productIv)
                titleTv.text = it.title
                val price = "$${it.price}"
                priceTv.text = price
                statusTv.text = it.status
                if (it.status == "Pending")
                    statusTv.setTextColor(requireContext().resources.getColor(R.color.red))
                else {
                    statusTv.setTextColor(requireContext().resources.getColor(R.color.green))
                }
                descriptionTv.text = it.description

            }
        }

    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}