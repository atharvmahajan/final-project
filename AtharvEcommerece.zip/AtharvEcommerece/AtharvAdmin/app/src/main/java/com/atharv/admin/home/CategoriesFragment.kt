package com.atharv.admin.home

import android.app.Activity
import android.content.DialogInterface
import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.isVisible
import com.bumptech.glide.Glide
import com.github.dhaval2404.imagepicker.ImagePicker
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.atharv.admin.MyApplication
import com.atharv.admin.R
import com.atharv.admin.adapters.CategoriesRecyclerAdapter
import com.atharv.admin.databinding.AddCateogoryLayoutDesignBinding
import com.atharv.admin.databinding.FragmentCategoriesBinding
import com.atharv.admin.model.Categories
import com.atharv.admin.util.DbConstants
import com.atharv.admin.util.showToast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CategoriesFragment : Fragment(R.layout.fragment_categories),
    CategoriesRecyclerAdapter.OnItemClickListener {

    companion object {
        const val TAG = "CategoriesFragment"
    }

    private val startForProfileImageResult =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->
            val resultCode = result.resultCode
            val data = result.data

            when (resultCode) {
                Activity.RESULT_OK -> {
                    //Image Uri will not be null for RESULT_OK
                    val fileUri = data?.data!!
                    imageUri = fileUri
                    categoryIV.setImageURI(imageUri)
//                    productImages.add(imageUri)
//                    recItemsList.add(imageUri)
//
////                    initImagesRec()
//                    adapter.notifyItemInserted(recItemsList.count() - 1)
//                    Log.d(TAG, "productImages: $productImages")
                    Log.d(TAG, "imageUri: $imageUri")

                }

                ImagePicker.RESULT_ERROR -> {
                    Toast.makeText(context, ImagePicker.getError(data), Toast.LENGTH_SHORT).show()
                }

                else -> {
                    Toast.makeText(context, "Task Cancelled", Toast.LENGTH_SHORT).show()
                }
            }
        }


    private var _binding: FragmentCategoriesBinding? = null
    private val binding get() = _binding!!
    private lateinit var imageUri: Uri
    private lateinit var categoryIV: ImageView
    private lateinit var db: FirebaseFirestore
    private lateinit var docRef: CollectionReference
    private val categoriesList = mutableListOf<Categories>()
    private lateinit var categoriesRecyclerAdapter: CategoriesRecyclerAdapter
    private var bottomSheetDialog: BottomSheetDialog? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCategoriesBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        hideProgressbar()
        db = Firebase.firestore
        docRef = db.collection(DbConstants.CATEGORIES)
        binding.apply {

            fabAddCategory.setOnClickListener {
                showAddCategory(null)
            }
        }


        getCategories()
    }

    private fun getCategories() {
        showProgressbar()
        docRef.orderBy("time", Query.Direction.DESCENDING).addSnapshotListener { value, error ->
            hideProgressbar()
            if (error != null) {
                showToast(requireContext(), error.message.toString())
                Log.e(TAG, "getCategories: ${error.message.toString()}")
                return@addSnapshotListener
            }

            categoriesList.clear()
            for (document in value!!) {
                val category = document.toObject(Categories::class.java)
                categoriesList.add(category)
            }

            initRecyclerView()
        }


        /*
                docRef.get().addOnSuccessListener {
                    hideProgressbar()
                    if (it.isEmpty) {
                        showToast(requireContext(), "Failed to fetch")
                    } else {

                        for (document in it) {
                            val category = document.toObject(Categories::class.java)
                            categoriesList.add(category)
                        }

                        initRecyclerView()
                    }
                }.addOnFailureListener {
                    showToast(requireContext(), it.message.toString())
                    hideProgressbar()
                    Log.e(TAG, "getCategories: ${it.message.toString()}")
                }
        */
    }

    private fun initRecyclerView() {

        if (categoriesList.isNotEmpty()) {
//            binding.recyclerView.man
            categoriesRecyclerAdapter =
                CategoriesRecyclerAdapter(categoriesList, this, requireContext())
            binding.recyclerView.adapter = categoriesRecyclerAdapter

        }
    }

    private fun showAddCategory(category: Categories?) {

        bottomSheetDialog = BottomSheetDialog(requireContext())
        val view = AddCateogoryLayoutDesignBinding.inflate(LayoutInflater.from(requireContext()))

        view.apply {

            progressBar.isVisible = false
            categoryIV = addImage

            category?.let {
                categoryEt.setText(it.name)
                Glide.with(requireContext()).load(it.image).into(addImage)
                addCategoryBtn.text = resources.getString(R.string.update)
            }
            addImage.setOnClickListener {
                ImagePicker.with(this@CategoriesFragment)
                    .compress(1024)         //Final image size will be less than 1 MB(Optional)
                    .maxResultSize(
                        1080,
                        1080
                    )  //Final image resolution will be less than 1080 x 1080(Optional)
                    .crop(16f, 16f)
                    .createIntent { intent ->
                        startForProfileImageResult.launch(intent)
                    }

            }
            addCategoryBtn.setOnClickListener {
                if (addCategoryBtn.text.toString() == "Update") {
                    updateCategory(category!!)
                } else {

                    if (!::imageUri.isInitialized) {
                        showToast(requireContext(), "Please select image first")
                        return@setOnClickListener
                    } else if (categoryEt.text.toString().isNullOrEmpty()) {
                        showToast(requireContext(), "Please enter category name first")
                        return@setOnClickListener
                    } else {
                        postCategory(view)
                    }
                }
            }
        }



        bottomSheetDialog?.apply {
            setContentView(view.root)
            show()
        }
    }

    private fun AddCateogoryLayoutDesignBinding.updateCategory(category: Categories) {


        progressBar.isVisible = true
        addCategoryBtn.isVisible = false

        if (::imageUri.isInitialized) {

            val storageRef = FirebaseStorage.getInstance().reference

            CoroutineScope(Dispatchers.IO).launch {

                val imageRef =
                    storageRef.child("categories/${category.id}")
                val uploadTask = imageRef.putFile(imageUri)
                uploadTask.addOnSuccessListener {
                    // Image uploaded successfully
                    // You can get the download URL or perform further operations here
                    val downloadUrlTask = imageRef.downloadUrl
                    downloadUrlTask.addOnSuccessListener { downloadUri ->
                        val imageUrl = downloadUri.toString()
                        // Save the imageUrl to your database or perform other actions
                        Log.d(TAG, "updateCat: $imageUrl")

                        val name = categoryEt.text.toString().trim()
                        val categoryMap = mapOf(
                            "name" to name,
                            "image" to imageUrl
                        )

                        postUpdateCategory(category, categoryMap)
                    }
                }.addOnFailureListener { e ->
                    Log.w(TAG, "Error adding document", e)
                    showToast(requireContext(), e.message.toString())
                    progressBar.isVisible = false
                    addCategoryBtn.isVisible = true

                }
            }
        } else {
            val name = categoryEt.text.toString().trim()
            val categoryMap = mapOf(
                "name" to name,
            )
            postUpdateCategory(category, categoryMap)
        }
    }

    private fun AddCateogoryLayoutDesignBinding.postUpdateCategory(
        category: Categories,
        categoryMap: Map<String, String>
    ) {
        docRef.document(category.id!!)
            .update(categoryMap)
            .addOnSuccessListener {
                progressBar.isVisible = false
                addCategoryBtn.isVisible = true
                showToast(requireContext(), "Category is updated.")
                bottomSheetDialog?.dismiss()
            }.addOnFailureListener {
                Log.w(TAG, "Error updating document", it)
                showToast(requireContext(), it.message.toString())
                progressBar.isVisible = false
                addCategoryBtn.isVisible = true

            }
    }

    private fun postCategory(view: AddCateogoryLayoutDesignBinding) {

        view.apply {

            progressBar.isVisible = true
            addCategoryBtn.isVisible = false


            val storageRef = FirebaseStorage.getInstance().reference
            val id = docRef.document().id

            CoroutineScope(Dispatchers.IO).launch {

                val imageRef =
                    storageRef.child("categories/${id}")
                val uploadTask = imageRef.putFile(imageUri)
                uploadTask.addOnSuccessListener {
                    // Image uploaded successfully
                    // You can get the download URL or perform further operations here
                    val downloadUrlTask = imageRef.downloadUrl
                    downloadUrlTask.addOnSuccessListener { downloadUri ->
                        val imageUrl = downloadUri.toString()
                        // Save the imageUrl to your database or perform other actions
                        Log.d(TAG, "postProduct: $imageUrl")

                        val name = categoryEt.text.toString().trim()
                        val categoryMap = hashMapOf(
                            "id" to id,
                            "name" to name,
                            "time" to FieldValue.serverTimestamp(),
                            "image" to imageUrl
                        )


                        docRef.document(id)
                            .set(categoryMap)
                            .addOnSuccessListener {

                                progressBar.isVisible = false
                                addCategoryBtn.isVisible = true
                                showToast(MyApplication.getAppContext(), "Category is saved.")
                                bottomSheetDialog?.dismiss()
                            }.addOnFailureListener {
                                Log.w(TAG, "Error adding document", it)
                                showToast(requireContext(), it.message.toString())
                                progressBar.isVisible = false
                                addCategoryBtn.isVisible = true

                            }
                    }
                }.addOnFailureListener { e ->
                    Log.w(TAG, "Error adding document", e)
                    showToast(requireContext(), e.message.toString())
                    progressBar.isVisible = false
                    addCategoryBtn.isVisible = true

                }
            }
        }
    }


    private fun hideProgressbar() {
        binding.apply {
            progressBar.progressBar.isVisible = false

        }
    }

    private fun showProgressbar() {
        binding.apply {
            progressBar.progressBar.isVisible = true

        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null

        bottomSheetDialog?.dismiss()
        bottomSheetDialog = null

    }

    override fun actionDeleteCategory(item: Categories, position: Int) {
        showDeleteConfirmation(item, position)


    }

    private fun showDeleteConfirmation(category: Categories, position: Int) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Confirm!")
            .setMessage("Please confirm if you want to delete this category. You can't undo this action.")
            .setPositiveButton("Yes") { dialogInterface: DialogInterface, i: Int ->

                docRef.document(category.id!!).delete().addOnSuccessListener {
                    try {
                        categoriesList.removeAt(position)
                        categoriesRecyclerAdapter.notifyItemRemoved(position)
                        showToast(requireContext(), "Category is Deleted.")
                    } catch (e: Exception) {
                        Log.e(TAG, "showDeleteConfirmation: ${e.message.toString()}")
                    }


                }.addOnFailureListener {
                    showToast(requireContext(), it.message.toString())
                    Log.e(TAG, "showDeleteConfirmation: ${it.message.toString()}")
                }
                dialogInterface.dismiss()

            }.setNegativeButton("Cancel") { dialogInterface: DialogInterface, i: Int ->
                dialogInterface.cancel()
            }.show()
    }

    override fun actionEditCategory(item: Categories, position: Int) {
        showAddCategory(item)
    }
}