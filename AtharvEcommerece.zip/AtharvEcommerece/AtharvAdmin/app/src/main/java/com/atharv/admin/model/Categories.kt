package com.atharv.admin.model

import java.util.Date

data class Categories(
    val id: String? = "",
    val name: String? = "",
    val time: Date? = null,
    val image: String? = ""

)
