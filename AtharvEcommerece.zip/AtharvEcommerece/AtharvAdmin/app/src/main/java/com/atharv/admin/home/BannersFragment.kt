package com.atharv.admin.home

import android.app.Activity
import android.content.DialogInterface
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.github.dhaval2404.imagepicker.ImagePicker
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObject
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.ktx.storage
import com.atharv.admin.MyApplication
import com.atharv.admin.R
import com.atharv.admin.adapters.BannersRecyclerAdapter
import com.atharv.admin.databinding.AddCateogoryLayoutDesignBinding
import com.atharv.admin.databinding.FragmentBannersBinding
import com.atharv.admin.model.Banners
import com.atharv.admin.util.DbConstants
import com.atharv.admin.util.showToast
import com.atharv.admin.util.toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BannersFragment : Fragment(), BannersRecyclerAdapter.OnItemClickListener {
    companion object {
        const val TAG = "BannersFragment"
    }

    private val startForProfileImageResult =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->
            val resultCode = result.resultCode
            val data = result.data

            when (resultCode) {
                Activity.RESULT_OK -> {
                    //Image Uri will not be null for RESULT_OK
                    val fileUri = data?.data!!
                    imageUri = fileUri
                    bannerIV.setImageURI(imageUri)
                    Log.d(CategoriesFragment.TAG, "imageUri: $imageUri")

                }

                ImagePicker.RESULT_ERROR -> {
                    Toast.makeText(context, ImagePicker.getError(data), Toast.LENGTH_SHORT).show()
                }

                else -> {
                    Toast.makeText(context, "Task Cancelled", Toast.LENGTH_SHORT).show()
                }
            }
        }


    private var _binding: FragmentBannersBinding? = null
    private val binding get() = _binding!!
    private lateinit var imageUri: Uri
    private lateinit var bannerIV: ImageView
    private lateinit var db: FirebaseFirestore
    private lateinit var docRef: CollectionReference
    private val bannersList = mutableListOf<Banners>()
    private lateinit var bannersRecyclerAdapter: BannersRecyclerAdapter
    private var bottomSheetDialog: BottomSheetDialog? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentBannersBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        hideProgressbar()
        db = Firebase.firestore
        docRef = db.collection(DbConstants.BANNERS)
        binding.apply {

            addBanner.setOnClickListener {
                showAddBanner(null, 0)
            }
        }


        getBanners()
    }

    private fun getBanners() {
        showProgressbar()
//        docRef.orderBy("time", Query.Direction.DESCENDING).addSnapshotListener { value, error ->
//            hideProgressbar()
//            if (error != null) {
//                requireContext().toast(error.message.toString())
//                Log.e(TAG, "getBanners: ${error.message.toString()}")
//                return@addSnapshotListener
//            }
//
//            bannersList.clear()
//            for (document in value!!) {
//                val banner = document.toObject(Banners::class.java)
//                bannersList.add(banner)
//            }
//
//            initRecyclerView()
//        }
        docRef.orderBy("time", Query.Direction.DESCENDING).get().addOnSuccessListener { result ->
            hideProgressbar()
            bannersList.clear()
            for (document in result!!) {
                val banner = document.toObject(Banners::class.java)
                bannersList.add(banner)
            }

            initRecyclerView()
        }
    }

    private fun initRecyclerView() {

        if (bannersList.isNotEmpty()) {
            bannersRecyclerAdapter = BannersRecyclerAdapter(bannersList, this, requireContext())
            binding.recyclerView.adapter = bannersRecyclerAdapter

        }
    }

    private fun showAddBanner(banner: Banners?, position: Int) {

        bottomSheetDialog = BottomSheetDialog(requireContext())
        val view = AddCateogoryLayoutDesignBinding.inflate(LayoutInflater.from(requireContext()))

        view.apply {

            progressBar.isVisible = false
            categoryEt.isVisible = false
            bannerIV = addImage

            banner?.let {
//                categoryEt.setText(it.name)
                Glide.with(requireContext()).load(it.image).into(addImage)
                addCategoryBtn.text = resources.getString(R.string.update)
            }
            addImage.setOnClickListener {
                ImagePicker.with(this@BannersFragment)
                    .compress(1024)         //Final image size will be less than 1 MB(Optional)
                    .maxResultSize(
                        1080, 1080
                    )  //Final image resolution will be less than 1080 x 1080(Optional)
                    .crop(16f, 9f).createIntent { intent ->
                        startForProfileImageResult.launch(intent)
                    }

            }
            addCategoryBtn.setOnClickListener {
                if (addCategoryBtn.text.toString() == "Update") {
                    updateBanner(banner!!, position)
                } else {

                    if (!::imageUri.isInitialized) {
                        requireContext().toast("Please select image first")
                        return@setOnClickListener
                    }
                    /*else if (categoryEt.text.toString().isNullOrEmpty()) {
                        requireContext().toast("Please enter category name first")
                        return@setOnClickListener
                    }*/
                    else {
                        postBanner(view)
                    }
                }
            }
        }



        bottomSheetDialog?.apply {
            setContentView(view.root)
            show()
        }
    }

    private fun AddCateogoryLayoutDesignBinding.updateBanner(banner: Banners, position: Int) {


        if (::imageUri.isInitialized) {
            progressBar.isVisible = true
            addCategoryBtn.isVisible = false
            val storageRef = FirebaseStorage.getInstance().reference

            CoroutineScope(Dispatchers.IO).launch {

                val imageRef = storageRef.child("${DbConstants.BANNERS}/${banner.id}")
                val uploadTask = imageRef.putFile(imageUri)
                uploadTask.addOnSuccessListener {
                    // Image uploaded successfully
                    // You can get the download URL or perform further operations here
                    val downloadUrlTask = imageRef.downloadUrl
                    downloadUrlTask.addOnSuccessListener { downloadUri ->
                        val imageUrl = downloadUri.toString()
                        // Save the imageUrl to your database or perform other actions
                        Log.d(CategoriesFragment.TAG, "updateBanner: $imageUrl")

                        val bannerMap = mapOf(
                            "image" to imageUrl
                        )

                        postUpdateBanner(banner, bannerMap, position)
                    }
                }.addOnFailureListener { e ->
                    Log.w(TAG, "Error adding document", e)
                    showToast(requireContext(), e.message.toString())
                    progressBar.isVisible = false
                    addCategoryBtn.isVisible = true

                }
            }
        } else {
            requireContext().toast("You didn't change photo.")
        }

    }

    private fun AddCateogoryLayoutDesignBinding.postUpdateBanner(
        banner: Banners, bannerMap: Map<String, String>, position: Int
    ) {
        docRef.document(banner.id!!).update(bannerMap).addOnSuccessListener {

            docRef.document(banner.id).get().addOnSuccessListener {
                val banner = it.toObject(Banners::class.java)
                bannersList[position] = banner!!
                bannersRecyclerAdapter.notifyItemChanged(position)
            }
            progressBar.isVisible = false
            addCategoryBtn.isVisible = true
            showToast(requireContext(), "Banner is updated.")
            bottomSheetDialog?.dismiss()
        }.addOnFailureListener {
            Log.w(TAG, "Error updating document", it)
            showToast(requireContext(), it.message.toString())
            progressBar.isVisible = false
            addCategoryBtn.isVisible = true

        }
    }

    private fun postBanner(view: AddCateogoryLayoutDesignBinding) {

        view.apply {

            progressBar.isVisible = true
            addCategoryBtn.isVisible = false


            val storageRef = FirebaseStorage.getInstance().reference
            val id = docRef.document().id

            CoroutineScope(Dispatchers.IO).launch {

                val imageRef = storageRef.child("${DbConstants.BANNERS}/${id}")
                val uploadTask = imageRef.putFile(imageUri)
                uploadTask.addOnSuccessListener {
                    // Image uploaded successfully
                    // You can get the download URL or perform further operations here
                    val downloadUrlTask = imageRef.downloadUrl
                    downloadUrlTask.addOnSuccessListener { downloadUri ->
                        val imageUrl = downloadUri.toString()
                        // Save the imageUrl to your database or perform other actions
                        Log.d(TAG, "postBanner: $imageUrl")

                        val bannerMap = hashMapOf(
                            "id" to id, "time" to FieldValue.serverTimestamp(), "image" to imageUrl
                        )


                        docRef.document(id).set(bannerMap).addOnSuccessListener {

                            docRef.document(id).get().addOnSuccessListener {
                                val banner = it.toObject(Banners::class.java)
                                bannersList.add(0, banner!!)
//                                bannersRecyclerAdapter.notifyItemInserted(0)
                            }

                            progressBar.isVisible = false
                            addCategoryBtn.isVisible = true
                            showToast(MyApplication.getAppContext(), "Banner is saved.")
                            bottomSheetDialog?.dismiss()
                        }.addOnFailureListener {
                            Log.w(TAG, "Error adding document", it)
                            showToast(requireContext(), it.message.toString())
                            progressBar.isVisible = false
                            addCategoryBtn.isVisible = true

                        }
                    }
                }.addOnFailureListener { e ->
                    Log.w(TAG, "Error adding document", e)
                    showToast(requireContext(), e.message.toString())
                    progressBar.isVisible = false
                    addCategoryBtn.isVisible = true

                }
            }
        }
    }


    private fun hideProgressbar() {
        binding.apply {
            progressBar.progressBar.isVisible = false

        }
    }

    private fun showProgressbar() {
        binding.apply {
            progressBar.progressBar.isVisible = true

        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null

        bottomSheetDialog?.dismiss()
        bottomSheetDialog = null

    }

    override fun actionDeleteBanner(item: Banners, position: Int) {
        showDeleteConfirmation(item, position)


    }

    private fun showDeleteConfirmation(banner: Banners, position: Int) {
        MaterialAlertDialogBuilder(requireContext()).setTitle("Confirm!")
            .setMessage("Please confirm if you want to delete this BANNER. You can't undo this action.")
            .setPositiveButton("Yes") { dialogInterface: DialogInterface, i: Int ->

                docRef.document(banner.id!!).delete().addOnSuccessListener {
                    bannersList.removeAt(position)
                    bannersRecyclerAdapter.notifyItemRemoved(position)
                    showToast(requireContext(), "Banner Is Deleted.")

                    val storage = Firebase.storage.reference
                    // Create a storage reference from our app
//                    val storageRef = storage.reference

                    // Create a reference to the file to delete
                    val desertRef = storage.child("${DbConstants.BANNERS}/${banner.id}")

                    // Delete the file
                    desertRef.delete().addOnSuccessListener {
                        // File deleted successfully
                    }.addOnFailureListener {
                        // Uh-oh, an error occurred!
                        Log.e(TAG, "showDeleteConfirmation: ${it.message}")
                    }

                }.addOnFailureListener {
                    showToast(requireContext(), it.message.toString())
                    Log.e(
                        TAG, "showDeleteConfirmation: ${it.message.toString()}"
                    )
                }
                dialogInterface.dismiss()

            }.setNegativeButton("Cancel") { dialogInterface: DialogInterface, i: Int ->
                dialogInterface.cancel()
            }.show()
    }

    override fun actionEditBanner(item: Banners, position: Int) {
        showAddBanner(item, position)
    }

    override fun actionActiveBanner(banner: Banners, position: Int, stateIsActive: Boolean) {
        binding.progressBar.progressBar.isVisible = true

        val bannerMap = mapOf(
            "bannerIsActive" to stateIsActive
        )
        docRef.document(banner.id!!).update(bannerMap).addOnSuccessListener {

            docRef.document(banner.id).get().addOnSuccessListener {
                val banner = it.toObject(Banners::class.java)
                bannersList[position] = banner!!
                bannersRecyclerAdapter.notifyItemChanged(position)
            }
            binding.progressBar.progressBar.isVisible = false
            showToast(requireContext(), "Banner is updated.")
            bottomSheetDialog?.dismiss()
        }.addOnFailureListener {
            Log.w(TAG, "Error updating document", it)
            showToast(requireContext(), it.message.toString())
            binding.progressBar.progressBar.isVisible = false
        }

    }
}
