package com.atharv.seller.authFragments

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.api.model.PlaceTypes
import com.google.android.libraries.places.widget.Autocomplete
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.atharv.seller.HomeActivity
import com.atharv.seller.databinding.FragmentSignUpBinding
import com.atharv.seller.utils.Constants
import com.atharv.seller.utils.DbConstants


class SignUpFragment : Fragment() {

    companion object {

        const val TAG = "SignUpFragment"
    }

    private val apiKey = "AIzaSyCVMtqT9zg6PGF-EkeBzpnFm5nNoaRPJeU"
    private var _binding: FragmentSignUpBinding? = null

    // This property is only valid between onCreateView and
// onDestroyView.
    private val binding get() = _binding!!
    private val db = Firebase.firestore


    private val startAutocomplete =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
                result: ActivityResult ->
            if (result.resultCode == Activity.RESULT_OK) {
                val intent = result.data
                if (intent != null) {
                    val place = Autocomplete.getPlaceFromIntent(intent)
                    Log.i(
                        TAG, "Place: ${place}, ${place.id}"
                    )
                    binding.locationEt.setText(place.address)
                }
            } else if (result.resultCode == Activity.RESULT_CANCELED) {
                // The user canceled the operation.
                Log.i(TAG, "User canceled autocomplete")
            }
        }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSignUpBinding.inflate(inflater, container, false)
        val view = binding.root

        // Initialize the SDK
        context?.applicationContext?.let {
            Places.initialize(it, apiKey)
            // Create a new PlacesClient instance
//            val placesClient = Places.createClient(it)

        }



        hideProgressBar()
        setClickListeners()

        return view
    }

    private fun setClickListeners() {

        binding.apply {

            locationEt.setOnClickListener {
                locationEt.keyListener = null

                // Set the fields to specify which types of place data to
                // return after the user has made a selection.
                val fields = listOf(Place.Field.ID, Place.Field.ADDRESS)

                // Start the autocomplete intent.
                val intent = Autocomplete.IntentBuilder(AutocompleteActivityMode.FULLSCREEN, fields)
                    .setTypesFilter(listOf(PlaceTypes.ADDRESS))
//                    .setCountries(listOf("NG"))
                    .build(requireContext())
                startAutocomplete.launch(intent)
            }

            signUpBtn.setOnClickListener {

                validateViews()

            }

            backButton.setOnClickListener {
                findNavController().popBackStack()
            }
        }

    }

    private fun validateViews() {

        binding.apply {

            if (shopNameEt.text.toString().isEmpty()) {
                shopNameInputLayout.error = "Shop Name can not be blank"
                shopNameInputLayout.requestFocus()
                return@apply

            } else if (emailEt.text.toString().isEmpty()) {
                emailInputLayout.error = "Email can not be blank"
                emailInputLayout.requestFocus()
                return@apply
            } else if (!Patterns.EMAIL_ADDRESS.matcher(emailEt.text.toString()).matches()) {
                emailInputLayout.error = "Email is invalid"
                emailInputLayout.requestFocus()
                return@apply
            } else if (phoneEt.text.toString().isEmpty()) {
                phoneInputLayout.error = "Phone number can not be blank"
                phoneInputLayout.requestFocus()
                return@apply
            } else if (locationEt.text.toString().isEmpty()) {
                locationInputLayout.error = "Location can not be blank"
                locationInputLayout.requestFocus()
                return@apply
            } else if (passwordEt.text.toString().isEmpty()) {
                passwordInputLayout.error = "Password can not be blank"
                passwordInputLayout.requestFocus()
                return@apply
            } else if (passwordEt.text.toString().length < 8) {
                passwordInputLayout.error = "Use 8 characters or more for your password"
                passwordInputLayout.requestFocus()
                return@apply
            } else if (confirmPasswordEt.text.toString().isEmpty()) {
                confirmPasswordInputLayout.error = "Password can not be blank"
                confirmPasswordInputLayout.requestFocus()
                return@apply
            } else if (confirmPasswordEt.text.toString().trim() != passwordEt.text.toString()
                    .trim()
            ) {
                confirmPasswordInputLayout.error = "Those passwords didn’t match. Try again."
                confirmPasswordInputLayout.requestFocus()
                return@apply
            } else {
                mapData()
            }
        }


    }

    private fun mapData() {

        binding.apply {
            val shopName = shopNameEt.text.toString().trim()
            val email = emailEt.text.toString().trim()
            val location = locationEt.text.toString().trim()
            val password = passwordEt.text.toString().trim()
            val phoneNumber = phoneEt.text.toString().trim()
            val userMap = hashMapOf<String, Any>(
                "shop" to shopName,
                "email" to email,
                "location" to location,
                "userType" to Constants.USER_TYPE,
                "phoneNumber" to phoneNumber,
            )

            signUpUser(userMap, password)
        }
    }

    private fun signUpUser(userMap: HashMap<String, Any>, password: String) {
        showProgressBar()
        val auth = Firebase.auth
        auth.createUserWithEmailAndPassword(userMap["email"].toString(), password)
            .addOnCompleteListener {
                if (it.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    Log.d(TAG, "createUserWithEmail:success")

                    val user = auth.currentUser
                    userMap["uid"] = user!!.uid
                    // Add a new document
                    db.collection(DbConstants.USERS)
                        .document(user.uid)
                        .set(userMap)
                        .addOnSuccessListener { documentReference ->
                            Log.d(TAG, "DocumentSnapshot added with ID: $documentReference")

                            updateUI(user)
                        }
                        .addOnFailureListener { e ->
                            Log.w(TAG, "Error adding document", e)
                            updateUI(null)
                        }


                } else {
                    // If sign in fails, display a message to the user.
                    Log.w(TAG, "createUserWithEmail:failure", it.exception)
                    Toast.makeText(
                        context,
                        it.exception?.message.toString(),
                        Toast.LENGTH_SHORT,
                    ).show()
                    updateUI(null)
                }
            }

    }

    private fun updateUI(user: FirebaseUser?) {


        user?.let {
            activity?.let {
                startActivity(Intent(it, HomeActivity::class.java))
                requireActivity().finish()
            }
        }

        hideProgressBar()

    }

    private fun hideProgressBar() {
        binding.apply {
            progressBar.isVisible = false
            signUpBtn.isVisible = true
        }
    }

    private fun showProgressBar() {
        binding.apply {
            progressBar.isVisible = true
            signUpBtn.isVisible = false
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}