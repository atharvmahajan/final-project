package com.atharv.admin

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.atharv.admin.auth.AuthActivity
import com.atharv.admin.home.HomeActivity


class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)


        Handler(Looper.getMainLooper()).postDelayed({

            if (Firebase.auth.currentUser != null) {
                startActivity(Intent(this@SplashActivity, HomeActivity::class.java))
                finish()
            } else {
                val mainIntent = Intent(this@SplashActivity, AuthActivity::class.java)
                startActivity(mainIntent)
                finish()
            }

        }, 1000)
    }
}