package com.atharv.seller.notification

import android.R
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.atharv.seller.MainActivity


@SuppressLint("MissingFirebaseInstanceTokenRefresh")
class MyFirebaseMessagingService : FirebaseMessagingService() {

    private val channelId = "shoplink_seller"
    private val channelName = "com.shoplinks.seller"
    private val channelDescription = ""
    private val notificationId = 1 // You can use different IDs for different notifications

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        // Handle the incoming message here and display the notification
        val title = remoteMessage.notification?.title
        val message = remoteMessage.notification?.body
        // Display the notification using NotificationManager or other methods
//        Helper.showToast(this, "$title \n $message")

        Log.d("FirebaseMessageService", "onMessageReceived: ${remoteMessage.notification?.body}")

//        createNotificationChannel(title, message)

        createNotifChannel()
    }


    private fun createNotificationChannel(title: String?, message: String?) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(channelId, channelName, importance)
            channel.description = channelDescription;

            val notificationManager =
                getSystemService(NotificationManager::class.java) as NotificationManager
            notificationManager.createNotificationChannel(channel)
//            showNotification(title, message)
        } else {
//            showNotificationBeforeOreo(title, message)
        }
    }


    @RequiresApi(Build.VERSION_CODES.M)
    private fun showNotification(title: String?, message: String?) {

        // Create the notification
        val builder: NotificationCompat.Builder =
            NotificationCompat.Builder(this, channelId)
                .setSmallIcon(R.drawable.sym_def_app_icon) // Replace with your app's small icon
                .setContentTitle("Your Notification Title")
                .setContentText("Your Notification Text")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)

        // Show the notification
        val notificationManager = getSystemService(
            NotificationManager::class.java
        ) as NotificationManager
        notificationManager.notify(notificationId, builder.build())
    }

    private fun showNotificationBeforeOreo(title: String?, message: String?) {

//         Create an intent to launch when the notification is clicked
        val intent = Intent(this, MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
        )

        // Build the notification
        val builder: NotificationCompat.Builder = NotificationCompat.Builder(this)
            .setSmallIcon(R.drawable.sym_def_app_icon) // Replace with your app's small icon
            .setContentTitle("Your Notification Title")
            .setContentText("Your Notification Text")
            .setAutoCancel(true) // Automatically remove the notification when clicked
            .setContentIntent(pendingIntent)

        // Show the notification
        val notificationManager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(notificationId, builder.build())
    }

    private fun createNotifChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_DEFAULT).apply {
                lightColor = Color.BLUE
                enableLights(true)
            }
            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

}
