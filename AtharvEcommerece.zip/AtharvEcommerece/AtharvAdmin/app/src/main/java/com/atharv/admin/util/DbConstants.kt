package com.atharv.admin.util

object DbConstants {

    const val ADMIN = "admin"
    const val PRODUCTS = "products"
    const val CATEGORIES = "categories"
    const val BANNERS = "banners"

}