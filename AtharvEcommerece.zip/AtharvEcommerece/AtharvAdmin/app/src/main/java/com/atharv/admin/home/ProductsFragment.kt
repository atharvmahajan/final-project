package com.atharv.admin.home

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.atharv.admin.adapters.ProductRecyclerAdapter
import com.atharv.admin.databinding.FragmentProductsBinding
import com.atharv.admin.model.Products
import com.atharv.admin.util.Constants
import com.atharv.admin.util.DbConstants


class ProductsFragment : Fragment(), ProductRecyclerAdapter.OnItemClickListener {

    companion object {
        const val TAG = "ProductsFragment"
    }

    private var _binding: FragmentProductsBinding? = null
    private val binding get() = _binding!!

    private val productsList = mutableListOf<Products>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProductsBinding.inflate(inflater, container, false)
        Log.d(TAG, "onCreateView: ")

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setUpClickListeners()
        fetchAllProducts()
    }

    private fun setUpClickListeners() {


    }

    private fun fetchAllProducts() {

        productsList.clear()
        showProgressBar()
        val db = Firebase.firestore
        val docRef = db.collection(DbConstants.PRODUCTS)

        docRef
            .whereEqualTo(Constants.STATUS_KEY, Constants.APPROVED)
            .get()
            .addOnSuccessListener { result ->
                if (!result.isEmpty) {
                    for (document in result) {
                        Log.d(TAG, "${document.id} => ${document.data}")
                        val products = document.toObject(Products::class.java)
                        productsList.add(products)
                    }

                    initRecyclerView()

//                    Toast.makeText(
//                        context,
//                        "Products fetched.",
//                        Toast.LENGTH_SHORT,
//                    ).show()
                } else {
                    Toast.makeText(
                        context,
                        "Failed to fetch products",
                        Toast.LENGTH_SHORT,
                    ).show()

                }
                hideProgressBar()
            }
            .addOnFailureListener { exception ->
                Log.d(TAG, "Error getting documents: ", exception)
                Toast.makeText(
                    context,
                    exception.message.toString(),
                    Toast.LENGTH_SHORT,
                ).show()

                hideProgressBar()
            }

    }

    private fun initRecyclerView() {

        if (productsList.isNotEmpty()) {
//            binding.recyclerView.man
            binding.recyclerView.adapter =
                ProductRecyclerAdapter(productsList, this, requireContext())
        }
    }

    private fun hideProgressBar() {
        binding.apply {
            progressBar.root.isVisible = false
        }
    }

    private fun showProgressBar() {
        binding.apply {
            progressBar.root.isVisible = true
        }
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onItemClick(item: Products) {

        val action =
            ProductsFragmentDirections.actionProductsFragToProductDetailFrag(
                item
            )
        findNavController().navigate(action)

    }
}