package com.shoplinks.shoplinkuser.adapters

import android.content.Context
import android.text.SpannableStringBuilder
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.text.bold
import androidx.core.text.color
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.shoplinks.shoplinkuser.R
import com.shoplinks.shoplinkuser.databinding.ProductsListLayoutBinding
import com.shoplinks.shoplinkuser.model.Products
import com.shoplinks.shoplinkuser.utils.getTimeAgo
import java.util.Date

class ProductRecyclerAdapter(
    private val itemList: List<Products>,
    private val listener: OnItemClickListener,
    private val context: Context
) :
    RecyclerView.Adapter<ProductRecyclerAdapter.ProductsViewHolder>() {

    interface OnItemClickListener {
        fun onItemClick(item: Products)
        fun onCartClick(item: Products)
        fun onSellerLocationClick(item: Products)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductsViewHolder {
        val binding =
            ProductsListLayoutBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ProductsViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProductsViewHolder, position: Int) {
        val currentItem = itemList[position]
        holder.bind(currentItem)
    }

    override fun getItemCount() = itemList.size

    inner class ProductsViewHolder(private val binding: ProductsListLayoutBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: Products) {
            binding.apply {
                soldOutImage.isVisible = item.soldOut

//                Picasso.get().load(item.imageUri).into(productIv)
                Glide.with(context).load(item.images?.get(0)).into(binding.productIv)
                titleTv.text = item.title
                val priceString = SpannableStringBuilder()
                    .append(context.resources.getString(R.string.currency_symbol))
                    .bold { append("${item.price}") }
                priceTv.text = priceString
//                val dateFormatted = item.time?.let {
//                    SimpleDateFormat(
//                        "dd MMM yy. hh:mm a",
//                        Locale.getDefault()
//                    ).format(it)
//                }

                val dateFormatted = Date().getTimeAgo(item.time)

                val myCustomizedString = SpannableStringBuilder()
                    .append(dateFormatted)
                    .append(" - ")
                    .append("${item.views}")
                    .append(" Views")

                timeTv.text = myCustomizedString
//                if (item.status == "Pending"){
//                    statusTv.setTextColor(context.resources.getColor(R.color.red))
//                } else {
//                    statusTv.setTextColor(context.resources.getColor(R.color.green))
//                }
//                statusTv.text = item.status
//                statusTv.isVisible = false

                root.setOnClickListener {
                    if (!item.soldOut) {
                        val position = adapterPosition
                        if (position != RecyclerView.NO_POSITION) {
                            val clickedItem = itemList[position]
                            listener.onItemClick(clickedItem)
                        }
                    }
                    /*else {

                        sendTopicNotification(
                            item.title!!,
                            "Not found this time",
                            requireContext().applicationContext
                        )

                    }*/
                }

//                sellerLocationIc.setOnClickListener {
//                    val position = adapterPosition
//                    if (position != RecyclerView.NO_POSITION) {
//                        val clickedItem = itemList[position]
//                        listener.onSellerLocationClick(clickedItem)
//                    }
//                }
            }


        }
    }
}