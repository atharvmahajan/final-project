package com.shoplinks.shoplinkuser.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.shoplinks.shoplinkuser.databinding.CategoryListItemBinding
import com.shoplinks.shoplinkuser.databinding.CategoryTitleItemBinding
import com.shoplinks.shoplinkuser.db.CartItem
import com.shoplinks.shoplinkuser.model.CategoryItem
import com.shoplinks.shoplinkuser.model.HeaderItem
import com.shoplinks.shoplinkuser.model.ListItem


class CategoriesRecyclerAdapter(
    private val itemList: List<ListItem>,
    private val context: Context,
    private val listener: OnItemClickListener
    ) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    interface OnItemClickListener {
        fun selectCategory(name: String?)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == ListItem.TYPE_CATEGORY) {
            val binding =
                CategoryListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            CategoryItemsViewHolder(binding)
        } else {
            val binding =
                CategoryTitleItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            HeaderItemsViewHolder(binding)
        }

    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {

        val type = getItemViewType(position)
        if (type == ListItem.TYPE_HEADER) {
            val header = itemList[position] as HeaderItem
            val holder = viewHolder as HeaderItemsViewHolder
            holder.bind(header)
        } else {
            val categoryItem = itemList[position] as CategoryItem
            val holder = viewHolder as CategoryItemsViewHolder
            holder.bind(categoryItem)
        }
    }

    override fun getItemViewType(position: Int): Int {
        return itemList[position].getType()
    }

    override fun getItemCount() = itemList.size

    inner class CategoryItemsViewHolder(private val binding: CategoryListItemBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(categoryItem: CategoryItem) {
            binding.apply {
                categoryName.text = categoryItem.name

                categoryName.setOnClickListener {
                    val position = adapterPosition
                    if (position != RecyclerView.NO_POSITION) {
//                        val clickedItem = itemList[position]
                        listener.selectCategory(categoryItem.name)
                    }
                }
            }

        }
    }

    inner class HeaderItemsViewHolder(private val binding: CategoryTitleItemBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(headerItem: HeaderItem) {
            binding.apply {
                title.text = headerItem.title
            }

        }
    }
}