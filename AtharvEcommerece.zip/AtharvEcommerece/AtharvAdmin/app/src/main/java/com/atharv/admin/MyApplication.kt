package com.atharv.admin

import android.app.Application
import android.content.Context

class MyApplication : Application() {


    companion object {
        private var context: Context? = null
        fun getAppContext(): Context {
            return MyApplication.context!!
        }
    }

    override fun onCreate() {
        super.onCreate()
        context = applicationContext
    }


}