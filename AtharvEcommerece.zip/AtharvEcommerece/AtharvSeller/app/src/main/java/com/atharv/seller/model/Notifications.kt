package com.atharv.seller.model

import java.io.Serializable
import java.util.*


data class Notifications(
    val category: String? ="",
    val phoneNumber: String? = "",
    val notificationMessage: String? = "",
    val time: Date? = null,

): Serializable
