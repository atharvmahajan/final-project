package com.atharv.seller.utils

object DbConstants {

    const val USERS = "users"
    const val PRODUCTS = "products"
    const val NOTIFICATIONS = "notifications"
    const val CATEGORIES = "categories"

}