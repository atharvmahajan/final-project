package com.atharv.admin.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.atharv.admin.databinding.BannerRecItemDesignBinding
import com.atharv.admin.model.Banners
import java.text.SimpleDateFormat
import java.util.Locale

class BannersRecyclerAdapter(
    private val itemList: List<Banners>,
    private val listener: OnItemClickListener,
    private val context: Context
) :
    RecyclerView.Adapter<BannersRecyclerAdapter.BannersViewHolder>() {

    private val listData: MutableList<Banners> = itemList as MutableList<Banners>

    interface OnItemClickListener {
        fun actionDeleteBanner(item: Banners, position: Int)
        fun actionEditBanner(item: Banners, position: Int)
        fun actionActiveBanner(item: Banners, position: Int, stateIsActive: Boolean)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BannersViewHolder {
        val binding =
            BannerRecItemDesignBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        return BannersViewHolder(binding)
    }

    override fun onBindViewHolder(holder: BannersViewHolder, position: Int) {
        val currentItem = listData[position]
        holder.bind(currentItem)
    }

    override fun getItemCount() = listData.size

    inner class BannersViewHolder(private val binding: BannerRecItemDesignBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: Banners) {
            binding.apply {

//                Picasso.get().load(item.image).into(imageView)
                Glide.with(context).load(item.image).into(bannerImageView)
                val dateFormatted = item.time?.let {
                    SimpleDateFormat(
                        "dd MMM yy. hh:mm a",
                        Locale.getDefault()
                    ).format(it)
                }

                bannerStateCb.isChecked = item.bannerIsActive

                deleteActionIv.setOnClickListener {
                    val position = adapterPosition
                    if (position != RecyclerView.NO_POSITION) {
                        val clickedItem = itemList[position]
                        listener.actionDeleteBanner(item, position)
                    }
//                    deleteItem(position)
                }
                editActionIv.setOnClickListener {
                    val position = adapterPosition
                    if (position != RecyclerView.NO_POSITION) {
                        val clickedItem = itemList[position]
                        listener.actionEditBanner(clickedItem, position)
                    }
                }
                bannerStateCb.setOnClickListener {
                    val position = adapterPosition
                    if (position != RecyclerView.NO_POSITION) {
                        val clickedItem = itemList[position]

                        val stateIsActive = bannerStateCb.isChecked

                        listener.actionActiveBanner(clickedItem, position, stateIsActive)
                    }
                }
            }


        }
    }

    fun deleteItem(index: Int) {
        listData.removeAt(index)
        notifyDataSetChanged()
    }
}