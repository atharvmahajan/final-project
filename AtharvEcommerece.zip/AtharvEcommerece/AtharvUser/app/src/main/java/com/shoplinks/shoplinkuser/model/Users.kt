package com.shoplinks.shoplinkuser.model

data class Users(
    val email: String? = "",
    val location: String? = "",
    val userName: String? = "",
    val uid: String? = "",
    val userType: String? = "",
    val phoneNumber: String? = "",
    )
