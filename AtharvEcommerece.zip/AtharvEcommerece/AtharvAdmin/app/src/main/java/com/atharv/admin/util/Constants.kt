package com.atharv.admin.util

object Constants {

    var ADMIN_EMAIL = ""
    const val PENDING = "Pending"
    const val APPROVED = "Approved"
    const val STATUS_KEY = "status"
}