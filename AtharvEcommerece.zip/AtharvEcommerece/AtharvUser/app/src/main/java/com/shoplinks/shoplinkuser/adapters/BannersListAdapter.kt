package com.shoplinks.shoplinkuser.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.shoplinks.shoplinkuser.databinding.BannersItemDesignBinding
import com.shoplinks.shoplinkuser.model.Banners

class BannersListAdapter : ListAdapter<Banners, RecyclerView.ViewHolder>(DiffCallBackImpl()) {

    private class DiffCallBackImpl : DiffUtil.ItemCallback<Banners>() {
        override fun areItemsTheSame(oldItem: Banners, newItem: Banners): Boolean =
            oldItem.id == newItem.id

        override fun areContentsTheSame(oldItem: Banners, newItem: Banners): Boolean =
            oldItem.id == newItem.id
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder =
        ItemViewHolder(
            BannersItemDesignBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item = getItem(position)
        val hold = holder as ItemViewHolder
        hold.onBind(item)
    }

    inner class ItemViewHolder(val binding: BannersItemDesignBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun onBind(banner: Banners) {
            Glide.with(binding.bannerImageView).load(banner.image).into(binding.bannerImageView)

        }

    }
}