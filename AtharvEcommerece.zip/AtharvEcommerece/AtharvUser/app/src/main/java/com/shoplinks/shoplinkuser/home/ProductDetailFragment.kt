package com.shoplinks.shoplinkuser.home

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.text.bold
import androidx.core.text.color
import androidx.core.view.isVisible
import androidx.navigation.fragment.navArgs
import com.bumptech.glide.Glide
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.shoplinks.shoplinkuser.R
import com.shoplinks.shoplinkuser.adapters.ImageSlideAdapter
import com.shoplinks.shoplinkuser.auth.SignInFragment
import com.shoplinks.shoplinkuser.databinding.BottomsheetAddCartItemLayoutBinding
import com.shoplinks.shoplinkuser.databinding.FragmentProductDetailBinding
import com.shoplinks.shoplinkuser.db.CartItem
import com.shoplinks.shoplinkuser.db.ShopLinkDatabase
import com.shoplinks.shoplinkuser.model.Products
import com.shoplinks.shoplinkuser.model.Users
import com.shoplinks.shoplinkuser.utils.DbConstants
import com.shoplinks.shoplinkuser.utils.toast
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class ProductDetailFragment : BaseFragment() {
    companion object {
        const val TAG = "ProductDetailFragment"
    }

    private var _binding: FragmentProductDetailBinding? = null
    private val binding get() = _binding!!
    private val productArg: ProductDetailFragmentArgs by navArgs()
    private lateinit var viewPagerAdapter: ImageSlideAdapter
    private  var users: Users? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentProductDetailBinding.inflate(inflater, container, false)

        hideProgressBar()
        showProduct()
        setUpClickListeners()
        return binding.root
    }


    private fun setUpClickListeners() {

        binding.apply {
            sellerLocationIc.setOnClickListener {
//                productArg.product?.let { it1 -> showCartBottomSheet(it1) }

                // Creates an Intent that will load a map of San Francisco
                val gmmIntentUri = Uri.parse("geo:0,0?q=${users?.location}")
                val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
                mapIntent.setPackage("com.google.android.apps.maps")
                startActivity(mapIntent)


            }

            whatsappTv.setOnClickListener {
                val url = "https://api.whatsapp.com/send?phone=${users?.phoneNumber}"
                val i = Intent(Intent.ACTION_VIEW)
                i.data = Uri.parse(url)
                startActivity(i)
            }
        }
    }

    private fun showCartBottomSheet(item: Products) {

        // on below line we are creating a new bottom sheet dialog.
        val dialog = BottomSheetDialog(requireContext())

        // on below line we are inflating a layout file which we have created.
//        val view = layoutInflater.inflate(R.layout.category_bottom_sheet_layout, null)
        val view =
            BottomsheetAddCartItemLayoutBinding.inflate(LayoutInflater.from(requireContext()))
        dialog.setContentView(view.root)
//        dialog.setCancelable(false)

        view.apply {


            launch {
                context?.let { it ->
                    val cartItem =
                        ShopLinkDatabase(it).getCartItemDao().getCartItem(item.productId!!)

                    cartItem?.let {
                        itemCountTv.text = it.quantity
                    } ?: let {
                        itemCountTv.text = "1"

                    }
                }
            }

            Glide.with(requireContext()).load(item.images?.get(0)).into(imageView)
            titleTv.text = item.title
            val priceString = SpannableStringBuilder()
                .append(resources.getString(R.string.currency_symbol))
                .bold { append("${item.price}") }
            priceTv.text = priceString
//            itemCountTv.text = "1"

            addItemCount.setOnClickListener {

                var count = itemCountTv.text.toString().toInt()
                ++count
                itemCountTv.text = count.toString()

            }

            minusItemCount.setOnClickListener {

                var count = itemCountTv.text.toString().toInt()

                if (count > 0) {
                    --count
                    itemCountTv.text = count.toString()
                }
            }

            addToCart.setOnClickListener {
                dialog.cancel()

                launch {

                    context?.let {
                        val cartItem = CartItem(
                            item.productId!!,
                            item.title!!,
                            item.price!!,
                            itemCountTv.text.toString(),
                            item.images!![0]
                        )
                        ShopLinkDatabase(it).getCartItemDao().addCartItem(cartItem)
                        it.toast("Added to cart")
                    }

                }

            }
        }


        dialog.show()

    }

    //test commit

    private fun showProduct() {

        productArg.product.let {

            fetchSellerLocation()
            binding.apply {


                viewPagerAdapter = ImageSlideAdapter(requireContext(), it?.images!!)
                viewpager.adapter = viewPagerAdapter

                titleTv.text = it.title
                val priceString = SpannableStringBuilder()
                    .append(resources.getString(R.string.currency_symbol))
                    .bold { append("${it.price}") }
                priceTv.text = priceString
                descriptionTv.text = it.description

                val dateFormatted = it.time?.let {
                    SimpleDateFormat(
                        "dd MMM yy. hh:mm a",
                        Locale.getDefault()
                    ).format(it)
                }

                dateTv.text = dateFormatted
                val myCustomizedString = SpannableStringBuilder()
                    .color(resources.getColor(R.color.black)) { bold { append("${it.views}") } }
                    .append(" Views")
                viewsTv.text = myCustomizedString

            }
        }

    }

    private fun hideProgressBar() {
        binding.apply {
//            progressBar.root.isVisible = false

        }
    }

    private fun showProgressBar() {
        binding.apply {
//            progressBar.root.isVisible = true

        }
    }

    private fun fetchSellerLocation() {
        val db = Firebase.firestore

        productArg.product?.sellerId?.let {
            db.collection(DbConstants.USERS)
                .document(it)
                .get()
                .addOnSuccessListener { result ->

                    if (result.exists()){
                        Log.d(SignInFragment.TAG, "${result.id} => ${result.data}")

                         users = result.toObject(Users::class.java)

                    }


                }
                .addOnFailureListener { exception ->
                    Log.w(SignInFragment.TAG, "Error getting documents.", exception)
                    users = null
                    Toast.makeText(
                        context,
                        exception.message.toString(),
                        Toast.LENGTH_SHORT,
                    ).show()
                }
        }

    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}