package com.shoplinks.shoplinkuser.adapters

import android.content.Context
import android.text.SpannableStringBuilder
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.text.bold
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.shoplinks.shoplinkuser.databinding.ItemCartListDesignBinding
import com.shoplinks.shoplinkuser.db.CartItem

class CartItemsRecyclerAdapter(
    private val itemList: List<CartItem>,
    private val listener: OnItemClickListener,
    private val context: Context
) :
    RecyclerView.Adapter<CartItemsRecyclerAdapter.CartItemsViewHolder>() {

    interface OnItemClickListener {
        fun onMinusClick(item: CartItem)
        fun onPlusClick(item: CartItem)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartItemsViewHolder {
        val binding =
            ItemCartListDesignBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CartItemsViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CartItemsViewHolder, position: Int) {
        val currentItem = itemList[position]
        holder.bind(currentItem)
    }

    override fun getItemCount() = itemList.size

    inner class CartItemsViewHolder(private val binding: ItemCartListDesignBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: CartItem) {
            binding.apply {

//                Picasso.get().load(item.imageUri).into(productIv)
                Glide.with(context).load(item.image).into(binding.imageView)
                titleTv.text = item.title
                val priceString = SpannableStringBuilder()
                    .append("$")
                    .bold { append(item.price) }
                priceTv.text = priceString

                itemCountTv.text = item.quantity

                val quantityString = SpannableStringBuilder()
                    .bold { append(item.quantity) }
                    .append(" PCS")

                quantityTv.text = quantityString

                minusItemCount.setOnClickListener {
                    val position = adapterPosition
                    if (position != RecyclerView.NO_POSITION) {
                        val clickedItem = itemList[position]
                        listener.onMinusClick(clickedItem)
                    }
                }

                addItemCount.setOnClickListener {
                    val position = adapterPosition
                    if (position != RecyclerView.NO_POSITION) {
                        val clickedItem = itemList[position]
                        listener.onPlusClick(clickedItem)
                    }
                }
            }


        }
    }
}