package com.shoplinks.shoplinkuser.model

import java.util.Date

data class Banners(
    val id: String? = "",
    val name: String? = "",
    val time: Date? = null,
    val image: String? = "",
    val bannerIsActive: Boolean = false
)
