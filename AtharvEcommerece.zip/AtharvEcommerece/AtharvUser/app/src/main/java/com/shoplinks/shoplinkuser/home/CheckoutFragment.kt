package com.shoplinks.shoplinkuser.home

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.shoplinks.shoplinkuser.R
import com.shoplinks.shoplinkuser.databinding.FragmentCheckoutBinding
import com.shoplinks.shoplinkuser.db.ShopLinkDatabase
import com.shoplinks.shoplinkuser.utils.toast
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class CheckoutFragment : BaseFragment() {

    companion object {

    }

    private var _binding: FragmentCheckoutBinding? = null
    private val binding get() = _binding!!
    private val totalCostArg: CheckoutFragmentArgs by navArgs()



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentCheckoutBinding.inflate(inflater, container, false)

        binding.apply {
            totalCostTv.text = "$${totalCostArg.totalCost.toString()}"

            placeOrderBtn.setOnClickListener {
                launch {
                    context?.let {
                        showProgressBar()
                        ShopLinkDatabase(it).getCartItemDao().delete()
                        delay(2500)
                        it.toast("Your order is place")
                        hideProgressBar()
//                        findNavController().navigate(R.id.action_checkoutFragment_to_homeFragment)
                    }


                }
            }
        }
        return binding.root
    }

    private fun hideProgressBar() {
        binding.apply {
            progressBar.root.isVisible = false
        }
    }

    private fun showProgressBar() {
        binding.apply {
            progressBar.root.isVisible = true
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}