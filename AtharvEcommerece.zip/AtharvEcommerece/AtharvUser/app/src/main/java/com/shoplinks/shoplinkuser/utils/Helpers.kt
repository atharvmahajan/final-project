package com.shoplinks.shoplinkuser.utils

import android.content.Context
import android.util.Log
import android.widget.Toast
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.shoplinks.shoplinkuser.auth.SignUpFragment
import okhttp3.*
import org.json.JSONObject
import java.io.IOException
import java.util.Calendar
import java.util.Date;

fun Context.toast(message: String) =
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()


fun sendTopicNotification(
    topic: String,
    notificationTitle: String,
    notificationMessage: String,
    phoneNumber: String,
    applicationContext: Context
) {
    val url = "https://fcm.googleapis.com/fcm/send"
    val serverKey =
        "AAAAM_YS1s8:APA91bEnsWm1-oVkRlXmKTLeS2stoE4wf7vkNyRngC8aqIF9H0vQU7yxt85doYfS4zkxxfv6qPfVHVY_y0AevA-bwnfhzHe0EcJ4ZAklFwaMWNI7v0KgA7mu72s7oFtBwBtPzkvilRdU" // Replace with your Firebase Cloud Messaging server key
//    val topic = "your_topic_name"

    val json = JSONObject()
    json.put("to", "/topics/$topic")
    val notification = JSONObject()
    notification.put("title", notificationTitle)
    notification.put("body", notificationMessage)
    json.put("notification", notification)

    val client = OkHttpClient()
    val mediaType = MediaType.parse("application/json")
    val requestBody = RequestBody.create(mediaType, json.toString())
    val request = Request.Builder()
        .url(url)
        .post(requestBody)
        .addHeader("Authorization", "key=$serverKey")
        .build()

    client.newCall(request).enqueue(object : Callback {
        override fun onFailure(call: Call, e: IOException) {
            // Handle the failure
            Log.e("MessageService", "onFailure: ${e.message}")
            e.message?.let { applicationContext.toast(it) }

        }

        override fun onResponse(call: Call, response: Response) {
            // Handle the response if needed
            Log.d("MessageService", "onResponse: ${response.isSuccessful}")
            val notifMap = hashMapOf<String, Any>(
                "category" to topic,
                "phoneNumber" to phoneNumber,
                "notificationMessage" to notificationMessage,
                "time" to FieldValue.serverTimestamp(),

                )
            val db = Firebase.firestore
            db.collection(DbConstants.NOTIFICATIONS)
                .add(notifMap)
                .addOnSuccessListener { documentReference ->
                    Log.d("NotificationSent", "DocumentSnapshot added with ID: $documentReference")
                    applicationContext.toast("You request is sent.")

                }
                .addOnFailureListener { e ->
                    Log.w(SignUpFragment.TAG, "Error adding document", e)
                    applicationContext.toast(e.message.toString())
                }
        }
    })
}

fun Date.getTimeAgo(time: Date?): String {
    val calendar = Calendar.getInstance()
    calendar.time = time

    val year = calendar.get(Calendar.YEAR)
    val month = calendar.get(Calendar.MONTH)
    val day = calendar.get(Calendar.DAY_OF_MONTH)
    val hour = calendar.get(Calendar.HOUR_OF_DAY)
    val minute = calendar.get(Calendar.MINUTE)

    val currentCalendar = Calendar.getInstance()

    val currentYear = currentCalendar.get(Calendar.YEAR)
    val currentMonth = currentCalendar.get(Calendar.MONTH)
    val currentDay = currentCalendar.get(Calendar.DAY_OF_MONTH)
    val currentHour = currentCalendar.get(Calendar.HOUR_OF_DAY)
    val currentMinute = currentCalendar.get(Calendar.MINUTE)

    return if (year < currentYear ) {
        val interval = currentYear - year
        if (interval == 1) "$interval year ago" else "$interval years ago"
    } else if (month < currentMonth) {
        val interval = currentMonth - month
        if (interval == 1) "$interval month ago" else "$interval months ago"
    } else  if (day < currentDay) {
        val interval = currentDay - day
        if (interval == 1) "$interval day ago" else "$interval days ago"
    } else if (hour < currentHour) {
        val interval = currentHour - hour
        if (interval == 1) "$interval hour ago" else "$interval hours ago"
    } else if (minute < currentMinute) {
        val interval = currentMinute - minute
        if (interval == 1) "$interval minute ago" else "$interval minutes ago"
    } else {
        "a moment ago"
    }
}

// To use it
//val timeAgo = someDate.getTimeAgo()