package com.atharv.admin.approveProducts

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.atharv.admin.adapters.ProductRecyclerAdapter
import com.atharv.admin.databinding.FragmentApproveProductsBinding
import com.atharv.admin.model.Products
import com.atharv.admin.util.Constants
import com.atharv.admin.util.DbConstants

class ApproveProductsFragment : Fragment(), ProductRecyclerAdapter.OnItemClickListener {

    companion object {
        const val TAG = "ApproveProductsFragment"
    }

    private var _binding: FragmentApproveProductsBinding? = null
    private val binding get() = _binding!!

    //    private var db = Firebase.firestore
    private val productsList = mutableListOf<Products>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentApproveProductsBinding.inflate(inflater, container, false)

        Log.d(TAG, "onCreateView: ")
        setUpClickListeners()
        fetchAllProducts()
        return binding.root
    }

    private fun setUpClickListeners() {


    }

    private fun fetchAllProducts() {

        productsList.clear()
        showProgressBar()
        val db = Firebase.firestore
        val docRef = db.collection(DbConstants.PRODUCTS)

        docRef
            .whereEqualTo(Constants.STATUS_KEY, Constants.PENDING)
            .get()
            .addOnSuccessListener { result ->
                if (!result.isEmpty) {
                    for (document in result) {
                        Log.d(TAG, "${document.id} => ${document.data}")
                        val products = document.toObject(Products::class.java)
                        productsList.add(products)
                    }

                    initRecyclerView()

//                    Toast.makeText(
//                        context,
//                        "Products fetched.",
//                        Toast.LENGTH_SHORT,
//                    ).show()
                } else {
                    Toast.makeText(
                        context,
                        "Failed to fetch products",
                        Toast.LENGTH_SHORT,
                    ).show()

                }
                hideProgressBar()
            }
            .addOnFailureListener { exception ->
                Log.d(TAG, "Error getting documents: ", exception)
                Toast.makeText(
                    context,
                    exception.message.toString(),
                    Toast.LENGTH_SHORT,
                ).show()

                hideProgressBar()
            }

    }

    private fun initRecyclerView() {

        if (productsList.isNotEmpty()) {
//            binding.recyclerView.man
            binding.recyclerView.adapter =
                ProductRecyclerAdapter(productsList, this, requireContext())
        }
    }

    private fun hideProgressBar() {
        binding.apply {
            progressBar.root.isVisible = false
        }
    }

    private fun showProgressBar() {
        binding.apply {
            progressBar.root.isVisible = true
        }
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onItemClick(item: Products) {

//        Toast.makeText(context, "Clicked: $item", Toast.LENGTH_SHORT).show()
        val action =
            ApproveProductsFragmentDirections.actionApproveProductsFragToProductDetailFrag(
                item
            )
        findNavController().navigate(action)

//        val bundle = Bundle()
//        bundle.putSerializable("product", item)
//        val intent = Intent(activity, ProductDetailActivity::class.java)
//        intent.putExtra("product", item)
//        startActivity(intent)
    }

}