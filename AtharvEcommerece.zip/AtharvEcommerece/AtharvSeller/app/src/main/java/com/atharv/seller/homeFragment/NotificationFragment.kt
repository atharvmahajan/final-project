package com.atharv.seller.homeFragment

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.atharv.seller.adapters.NotificationsRecyclerAdapter
import com.atharv.seller.databinding.FragmentNotificationBinding
import com.atharv.seller.model.Notifications
import com.atharv.seller.model.Users
import com.atharv.seller.utils.DbConstants
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class NotificationFragment : Fragment(), NotificationsRecyclerAdapter.OnItemClickListener {
    companion object {
        const val TAG = "NotificationFragment"
    }

    private var _binding: FragmentNotificationBinding? = null
    private val binding get() = _binding!!
    private val db = Firebase.firestore
    private val notificationList = mutableListOf<Notifications>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentNotificationBinding.inflate(inflater, container, false)
        val view = binding.root

        hideProgressBar()
        fetchNotifications()
        return view
    }

    private fun fetchNotifications() {

        var categoryList: MutableList<String>
        val db = Firebase.firestore
        val docRef = db.collection(DbConstants.NOTIFICATIONS)
        val userDocRef = db.collection(DbConstants.USERS)
        CoroutineScope(Dispatchers.IO).launch {
            userDocRef.document(Firebase.auth.currentUser!!.uid)
                .get().addOnSuccessListener {

                    val user = it.toObject(Users::class.java)
                    Log.d(TAG, "fetchNotifications: ${user.toString()}")

                    user?.let { safeUser ->
                        categoryList = safeUser.topics as MutableList<String>
                        Log.d(TAG, "fetchNotifications: $categoryList")

                        notificationList.clear()
                        showProgressBar()

                        docRef
                            .get()
                            .addOnSuccessListener { result ->
                                if (!result.isEmpty) {
                                    for (document in result) {
                                        Log.d(
                                            HomeFragment.TAG,
                                            "${document.id} => ${document.data}"
                                        )
                                        val notifications =
                                            document.toObject(Notifications::class.java)

                                        if (categoryList.contains(notifications.category)) {
                                            notificationList.add(notifications)

                                        }

                                    }

                                    initRecyclerView()

                                    Toast.makeText(
                                        context,
                                        "Notifications fetched.",
                                        Toast.LENGTH_SHORT,
                                    ).show()
                                } else {
                                    Toast.makeText(
                                        context,
                                        "Failed to fetch products",
                                        Toast.LENGTH_SHORT,
                                    ).show()

                                }
                                hideProgressBar()
                            }
                            .addOnFailureListener { exception ->
                                Log.d(HomeFragment.TAG, "Error getting documents: ", exception)
                                Toast.makeText(
                                    context,
                                    exception.message.toString(),
                                    Toast.LENGTH_SHORT,
                                ).show()

                                hideProgressBar()
                            }
                    }

                }.addOnFailureListener {

                }
        }


    }

    private fun initRecyclerView() {

        if (notificationList.isNotEmpty()) {
//            binding.recyclerView.man
            binding.recyclerView.adapter =
                NotificationsRecyclerAdapter(notificationList, this, requireContext())
        }
    }

    private fun hideProgressBar() {
        binding.apply {
            progressBar.root.isVisible = false
        }
    }

    private fun showProgressBar() {
        binding.apply {
            progressBar.root.isVisible = true
        }
    }

    override fun onItemClick(item: Notifications) {

    }

    override fun onClickWhatsappIcon(item: Notifications) {

        item.phoneNumber?.let {
            val url = "https://api.whatsapp.com/send?phone=$it"
            val i = Intent(Intent.ACTION_VIEW)
            i.data = Uri.parse(url)
            startActivity(i)
        }

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}