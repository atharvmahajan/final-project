package com.shoplinks.shoplinkuser

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.shoplinks.shoplinkuser.auth.AuthActivity
import com.shoplinks.shoplinkuser.home.HomeActivity

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

//        FirebaseApp.initializeApp(applicationContext)

        Handler(Looper.getMainLooper()).postDelayed({

            if (Firebase.auth.currentUser != null) {
                startActivity(Intent(this@SplashActivity, HomeActivity::class.java))
                finish()
            } else {
                val mainIntent = Intent(this@SplashActivity, AuthActivity::class.java)
                startActivity(mainIntent)
                finish()
            }

        }, 1000)
    }
}