package com.atharv.admin.auth

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.atharv.admin.databinding.FragmentSignUpBinding
import com.atharv.admin.home.HomeActivity
import com.atharv.admin.util.DbConstants


class SignUpFragment : Fragment() {

    companion object {
        const val TAG = "SignUpFragment"
    }

    private var _binding: FragmentSignUpBinding? = null

    // This property is only valid between onCreateView and
// onDestroyView.
    private val binding get() = _binding!!
    private val db = Firebase.firestore

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSignUpBinding.inflate(inflater, container, false)
        val view = binding.root

        hideProgressBar()
        setClickListeners()

        return view
    }

    private fun setClickListeners() {

        binding.apply {
            signUpBtn.setOnClickListener {

                validateViews()

            }

            backButton.setOnClickListener {
                findNavController().popBackStack()
            }
        }

    }

    private fun validateViews() {

        binding.apply {

             if (emailEt.text.toString().isEmpty()) {
                emailInputLayout.error = "Email can not be blank"
            } else if (!Patterns.EMAIL_ADDRESS.matcher(emailEt.text.toString()).matches()) {
                emailInputLayout.error = "Email is invalid"
            }  else if (passwordEt.text.toString().isEmpty()) {
                passwordInputLayout.error = "Password can not be blank"
            } else if (passwordEt.text.toString().length < 8) {
                passwordInputLayout.error = "Use 8 characters or more for your password"
            } else if (confirmPasswordEt.text.toString().isEmpty()) {
                confirmPasswordInputLayout.error = "Password can not be blank"
            } else if (confirmPasswordEt.text.toString().trim() != passwordEt.text.toString()
                    .trim()
            ) {
                confirmPasswordInputLayout.error = "Those passwords didn’t match. Try again."
            } else {
                mapData()
            }
        }


    }

    private fun mapData() {

        binding.apply {
            val email = emailEt.text.toString().trim()
            val password = passwordEt.text.toString().trim()
            val userMap = hashMapOf<String, Any>(
                "email" to email,
                "userType" to DbConstants.ADMIN
            )

            signUpUser(userMap, password)
        }
    }

    private fun signUpUser(userMap: HashMap<String, Any>, password: String) {
        showProgressBar()
        val auth = Firebase.auth
        auth.createUserWithEmailAndPassword(userMap["email"].toString(), password)
            .addOnCompleteListener {
                if (it.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    Log.d(TAG, "createUserWithEmail:success")

                    val user = auth.currentUser
                    userMap["uid"] = user!!.uid
                    // Add a new document
                    db.collection(DbConstants.ADMIN)
                        .document(user.uid)
                        .set(userMap)
                        .addOnSuccessListener { documentReference ->
                            Log.d(TAG, "DocumentSnapshot added with ID: $documentReference")

                            updateUI(user)
                        }
                        .addOnFailureListener { e ->
                            Log.w(TAG, "Error adding document", e)
                            updateUI(null)
                        }


                } else {
                    // If sign in fails, display a message to the user.
                    Log.w(TAG, "createUserWithEmail:failure", it.exception)
                    Toast.makeText(
                        context,
                        it.exception?.message.toString(),
                        Toast.LENGTH_SHORT,
                    ).show()
                    updateUI(null)
                }
            }

    }

    private fun updateUI(user: FirebaseUser?) {


        user?.let {
            activity?.let {
                startActivity(Intent(it, HomeActivity::class.java))
                requireActivity().finish()
            }
        }

        hideProgressBar()

    }

    private fun hideProgressBar() {
        binding.apply {
            progressBar.isVisible = false
            signUpBtn.isVisible = true
        }
    }

    private fun showProgressBar() {
        binding.apply {
            progressBar.isVisible = true
            signUpBtn.isVisible = false
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }


}