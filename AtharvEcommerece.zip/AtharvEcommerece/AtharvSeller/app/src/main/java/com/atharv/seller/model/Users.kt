package com.atharv.seller.model

import java.io.Serializable

data class Users(
    val email: String? = "",
    val location: String? = "",
    val shop: String? = "",
    val uid: String? = "",
    val userType: String? = "",
    val phoneNumber: String? = "",
    val topics: List<String>? = null
    ): Serializable
